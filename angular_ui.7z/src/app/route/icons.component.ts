import { Component, OnInit, ViewChild } from '@angular/core';

import { NgModule } from '@angular/core';

import { Router } from '@angular/router';
import { retry } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/add/operator/catch';
import { EMPTY } from 'rxjs';

import { Injectable } from '@angular/core';
import { CanDeactivate } from '@angular/router';

import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { WebcamImage, WebcamInitError, WebcamUtil } from 'ngx-webcam';
import { SignaturePad } from 'angular2-signaturepad/signature-pad';


@Injectable()
export class ConfirmDeactivateGuard3 implements CanDeactivate<IconsComponent> {

  canDeactivate(target: IconsComponent) {
    if (target.checkIfStarted()) {
      return window.confirm('Are you sure?');
    }
    return true;
  }
}

@NgModule({
  providers: [
    ConfirmDeactivateGuard3
  ]
})

@Component({
  selector: 'app-icons',
  templateUrl: './icons.component.html',
  styleUrls: ['./icons.component.css']
})
export class IconsComponent implements OnInit {

  @ViewChild('signpad1') signaturePad: SignaturePad;
  @ViewChild('signpad2') signaturePad2: SignaturePad;
  @ViewChild('signpad3') signaturePad3: SignaturePad;
 
  private signaturePadOptions:  object= { // passed through to szimek/signature_pad constructor
    'minWidth': .5,
    penColor:'rgb(7, 8, 7)',
    backgroundColor:'rgb(255,255,255)',
    'canvasWidth': 400,
    'canvasHeight': 100
    
  };
  public showWebcam = true;
  public allowCameraSwitch = true;
  public multipleWebcamsAvailable = false;
  public deviceId: string;
  public videoOptions: MediaTrackConstraints = {
    // width: {ideal: 1024},
    // height: {ideal: 576}
  };
  public errors: WebcamInitError[] = [];

  // latest snapshot
  public webcamImage: WebcamImage = null;
  public webcamImageArr: any = []

  // webcam snapshot trigger
  private trigger: Subject<void> = new Subject<void>();
  // switch to next / previous / specific webcam; true/false: forward/backwards, string: deviceId
  private nextWebcam: Subject<boolean | string> = new Subject<boolean | string>();

  request_img: any = []
  response_img: any = null
  signature_img_custodian1: boolean= false
  signature_img_custodian2: boolean= false
  signature_img_auditor: boolean= false

  signatureImage_custodian1: any= null;
  signatureImage_custodian2: any= null;
  signatureImage_auditor: any= null;

  emp_id_list: any = []
  name_cust_list: any = []

  image_names: string = null
  date_img: any = null

  server_json: any
  server_name: string
  service_name: string
  service_name_datetime: any
  service_name_custodian: any
  response_datetime: any
  response_custodian: any


  request: any
  response: any

  service_name_loc: string
  locations: any
  regions: any
  zones: any

  login_token: any
  access: any

  review_mode: boolean = false
  incomplete: boolean = false

  switch1: boolean = false
  switch2: boolean = false
  switch3: boolean = false
  switch4: boolean = false
  switch5: boolean = false
  switch6: boolean = false
  switch7: boolean = false
  switch8: boolean = false
  switch9: boolean = false
  switch10: boolean = false
  switch11: boolean = false
  switch12: boolean = false
  switch13: boolean = false
  switch14: boolean = false
  switch15: boolean = false
  switch16: boolean = false
  switch17: boolean = false
  switch18: boolean = false
  switch19: boolean = false
  switch20: boolean = false

  rating1: number = null
  rating2: number = null
  rating3: number = null
  rating4: number = null
  rating5: number = null
  rating6: number = null
  rating7: number = null
  rating8: number = null
  rating9: number = null
  rating10: number = null
  rating11: number = null
  rating12: number = null
  rating13: number = null
  rating14: number = null
  rating15: number = null
  rating16: number = null
  rating17: number = null
  rating18: number = null
  rating19: number = null
  rating20: number = null
  rating21: number = null
  rating22: number = null

  total_score: number = null
  risk_score: string = null

  all_fleet: boolean = false
  all_crew: boolean = false
  all_operations: boolean = false
  all_reporting: boolean = false
  all_data: boolean = false


  location_name: string
  audit_done_by: string
  date_of_audit: string
  route_number: string
  route_start_time: string
  route_end_time: string
  vehicle_number: string
  own: string
  name_agency: string = null
  name_driver: string
  name_cust1: string
  emp_id1: string
  name_cust2: string
  emp_id2: string
  name_guard1: string = null
  name_guard2: string = null
  number_of_guards: number = 0
  comments: string = null

  f8c1: string = null
  f10c1: string = null

  region: string
  zone: string
  location: string

  sent_to_server: boolean = false
  error_sending: boolean = true

  save_info: any = null
  save_json: string = null

  date: Date = new Date()

  lat_stamp: number = 0
  long_stamp: number = 0


  image_upload_url: string
  confirm_pressed: boolean = false

  constructor(private router: Router, private http: HttpClient) { }


  ngOnInit() {

    this.confirm_pressed = false

    this.server_json = require('./../../../config.json');
    this.server_name = this.server_json['server'];
    this.service_name = this.server_name.concat('/route')
    this.service_name_loc = this.server_name.concat('/demographic')
    this.service_name_datetime = this.server_name.concat('/datetime')
    this.service_name_custodian = this.server_name.concat('/custodian')
    this.image_upload_url = this.server_name.concat('/images')


    this.login_token = localStorage.getItem('CMSAppUserLogin');
    if (this.login_token) {
      this.access = JSON.parse(this.login_token);
    }
    else {
      this.router.navigateByUrl('/', { skipLocationChange: false }).then(() =>
        this.router.navigate(["/login"]));
    }

    this.region = this.access['region']
    this.zone = this.access['zone']
    this.location = this.access['location']

    this.audit_done_by = this.access['emp_id'] + " " + this.access['name']


    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Frame-Options': 'DENY'
      })
    };

    if (this.server_name) {
      this.http.post(this.service_name_datetime, {}, httpOptions)
        .catch(error => {
          alert("Could not connect to the server. Retry after some time.")
          return EMPTY
        })
        .subscribe(data => {
          this.response_datetime = data
          this.date_of_audit = this.response_datetime['date_server']
        });
    }

    this.save_json = localStorage.getItem('CMSAppUserSavedRoute')
    this.save_info = JSON.parse(this.save_json)
    if (this.save_info) {
      [this.switch1, this.switch2, this.switch3, this.switch4, this.switch5, this.switch6, this.switch7, this.switch8, this.switch9, this.switch10, this.switch11, this.switch12, this.switch13, this.switch14, this.switch15, this.switch16, this.switch17, this.switch18, this.switch19, this.switch20,
      this.f8c1, this.f10c1, this.location_name,
      this.audit_done_by,
      this.date_of_audit,
      this.route_number,
      this.route_start_time,
      this.route_end_time,
      this.vehicle_number,
      this.own,
      this.name_agency,
      this.name_driver,
      this.name_cust1,
      this.emp_id1,
      this.name_cust2,
      this.emp_id2,
      this.name_guard1,
      this.name_guard2,
      this.number_of_guards,
      this.comments,
      this.all_fleet, this.all_crew, this.all_operations, this.all_reporting, this.all_data, this.signatureImage_custodian1,this.signatureImage_custodian2,this.signatureImage_auditor,this.access['zone'], this.access['region'], this.access['location']] = this.save_info
    }

    this.getDemographic()
    this.location_name = this.access['location']

    this.getCustodianData()


    WebcamUtil.getAvailableVideoInputs()
      .then((mediaDevices: MediaDeviceInfo[]) => {
        this.multipleWebcamsAvailable = mediaDevices && mediaDevices.length > 1;
      });

  }

  public triggerSnapshot(): void {
    this.trigger.next();
  }

  public toggleWebcam(): void {
    this.showWebcam = !this.showWebcam;
  }

  public handleInitError(error: WebcamInitError): void {
    this.errors.push(error);
  }

  public showNextWebcam(directionOrDeviceId: boolean | string): void {
    this.nextWebcam.next(directionOrDeviceId);
  }


  public handleImage(webcamImage: WebcamImage): void {
    this.webcamImage = webcamImage;
    if (this.webcamImageArr.length < 4) {
      this.webcamImageArr.push(this.webcamImage);
    }
    else {
      alert("Maximum 4 images are allowed.")
    }
  }

  public cameraWasSwitched(deviceId: string): void {
    this.deviceId = deviceId;
  }

  public get triggerObservable(): Observable<void> {
    return this.trigger.asObservable();
  }

  public get nextWebcamObservable(): Observable<boolean | string> {
    return this.nextWebcam.asObservable();
  }

  getCustodianData() {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Frame-Options': 'DENY'
      })
    };
    this.http.post(this.service_name_custodian, {}, httpOptions)
      .catch(error => {
        alert("Could not connect to the server. Retry after some time.")
        return EMPTY
      })
      .subscribe(data => {
        this.response_custodian = data
        if (this.response_custodian['status'] && this.response_custodian['status'] == "Success") {
          this.emp_id_list = this.response_custodian['emp_id']
          this.name_cust_list = this.response_custodian['name_cust']
        }
        else {
          alert('Could not fetch Custodian list from the server.')
        }
      });
  }


   showImage(type) {
    console.log(type)
    if(type==='c1') {
      this.signature_img_custodian1=true
      this.signatureImage_custodian1 = this.signaturePad.toDataURL('image/png,0.5');
      console.log("c1");
      console.log(this.signatureImage_custodian1);
    }
    if(type==='c2') {
      this.signature_img_custodian2=true
      this.signatureImage_custodian2 = this.signaturePad2.toDataURL('image/png,0.5');
      console.log("c2");
      console.log(this.signatureImage_custodian2);
    }
    if(type==='A') {
      this.signature_img_auditor=true
      this.signatureImage_auditor = this.signaturePad3.toDataURL('image/png,0.5');
      console.log("A");
      console.log(this.signatureImage_auditor);
    }
    console.log("inside signature")
  }
  resetSign(type){

    if(type==='c1') {
      console.log("inside reset")
      this.signature_img_custodian1=false
      this.signaturePad.clear();
    }
    if(type==='c2') {
      console.log("inside reset")
      this.signature_img_custodian2=false
      this.signaturePad2.clear();
    }
    if(type==='A') {
      console.log("inside reset")
      this.signature_img_auditor=false
    this.signaturePad3.clear();
    }
  }



  formatDate(date) {
    var dateParts = date.split('-')
    var d = new Date(+dateParts[2], dateParts[1] - 1, +dateParts[0]),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();

    if (month.length < 2)
      month = '0' + month;
    if (day.length < 2)
      day = '0' + day;

    return [year, month, day].join('');
  }

  uploadImages() {

    this.date_img = this.formatDate(this.date_of_audit)
    this.request_img = []

    if (this.webcamImageArr[0]) {

      this.image_names = "Route/" + this.date_img.slice(0, 6) + "/" + this.location_name.split(' ').join('_') + "_" + this.date_img + "_1.jpg"

      this.request_img.push({
        "Name": "Route/" + this.date_img.slice(0, 6) + "/" + this.location_name.split(' ').join('_') + "_" + this.date_img + "_1.jpg",
        "Image": this.webcamImageArr[0]['imageAsBase64'],
        "ImageType": "jpg"
      })
    }
    if (this.webcamImageArr[1]) {

      this.image_names += ",Route/" + this.date_img.slice(0, 6) + "/" + this.location_name.split(' ').join('_') + "_" + this.date_img + "_2.jpg"

      this.request_img.push({
        "Name": "Route/" + this.date_img.slice(0, 6) + "/" + this.location_name.split(' ').join('_') + "_" + this.date_img + "_2.jpg",
        "Image": this.webcamImageArr[1]['imageAsBase64'],
        "ImageType": "jpg"
      })
    }
    if (this.webcamImageArr[2]) {

      this.image_names += ",Route/" + this.date_img.slice(0, 6) + "/" + this.location_name.split(' ').join('_') + "_" + this.date_img + "_3.jpg"

      this.request_img.push({
        "Name": "Route/" + this.date_img.slice(0, 6) + "/" + this.location_name.split(' ').join('_') + "_" + this.date_img + "_3.jpg",
        "Image": this.webcamImageArr[2]['imageAsBase64'],
        "ImageType": "jpg"
      })
    }
    if (this.webcamImageArr[3]) {

      this.image_names += ",Route/" + this.date_img.slice(0, 6) + "/" + this.location_name.split(' ').join('_') + "_" + this.date_img + "_4.jpg"

      this.request_img.push({
        "Name": "Route/" + this.date_img.slice(0, 6) + "/" + this.location_name.split(' ').join('_') + "_" + this.date_img + "_4.jpg",
        "Image": this.webcamImageArr[3]['imageAsBase64'],
        "ImageType": "jpg"
      })
    }


    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Frame-Options': 'DENY'
      })
    };
    this.http.post(this.image_upload_url, this.request_img, httpOptions)
      .catch(error => {
        alert("Could not connect to the server. Retry after some time.")
        return EMPTY
      })
      .subscribe(data => {
        this.response_img = data
        if (this.response_img['IsSuccess']) {
          this.callFinalAPI()
        }
        else {
          alert("Could not upload images to the server. Please edit and retry.")
        }
      });

  }


  getDemographic() {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Frame-Options': 'DENY'
      })
    };

    this.http.post(this.service_name_loc, { 'username': this.access['username'], 'zone': this.access['zone'], 'region': this.access['region'] }, httpOptions)
      .catch(error => {
        alert("Could not connect to the server. Retry after some time.")
        return EMPTY
      })
      .subscribe(data => {
        this.regions = data['regions']
        this.locations = data['locations']
        this.zones = data['zones']
      });
  }




  resetButton() {
    this.scrollTop()
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() =>
      this.router.navigate(["/route"]));
  }

  submitButton() {

    this.getLocation()

    if (!this.route_start_time.match(/^(?:2[0-3]|[01][0-9]):[0-5][0-9]$/) || !this.route_end_time.match(/^(?:2[0-3]|[01][0-9]):[0-5][0-9]$/)) {
      this.route_start_time = null
      this.route_end_time = null
      alert('Invalid time format, use HH:MM');
    }

    this.checkGeneralData()

    this.error_sending = false

    if (this.all_fleet && this.f8c1 && this.all_crew && this.all_operations && this.f10c1 && this.all_reporting && this.all_data) {

      this.incomplete = false
      this.review_mode = true

      this.saveLocal()
      this.calculateRatings()
      this.scrollTop()
    }
    else {
      this.incomplete = true
    }
  }

  saveLocal() {
    this.save_info = [this.switch1, this.switch2, this.switch3, this.switch4, this.switch5, this.switch6, this.switch7, this.switch8, this.switch9, this.switch10, this.switch11, this.switch12, this.switch13, this.switch14, this.switch15, this.switch16, this.switch17, this.switch18, this.switch19, this.switch20,
    this.f8c1, this.f10c1,
    this.location_name,
    this.audit_done_by,
    this.date_of_audit,
    this.route_number,
    this.route_start_time,
    this.route_end_time,
    this.vehicle_number,
    this.own,
    this.name_agency,
    this.name_driver,
    this.name_cust1,
    this.emp_id1,
    this.name_cust2,
    this.emp_id2,
    this.name_guard1,
    this.name_guard2,
    this.number_of_guards,
    this.comments,
    this.all_fleet, this.all_crew, this.all_operations, this.all_reporting, this.all_data,this.signatureImage_custodian1,this.signatureImage_custodian2,this.signatureImage_auditor, this.access['zone'], this.access['region'], this.access['location']]
    localStorage.setItem('CMSAppUserSavedRoute', JSON.stringify(this.save_info))
  }

  deleteLocal() {
    localStorage.removeItem('CMSAppUserSavedRoute')
  }

  editButton() {
    this.scrollTop()
    this.review_mode = false
    this.confirm_pressed = false
  }

  confirmButton() {
    this.confirm_pressed = true

    if (!this.webcamImageArr[0]) {
      this.callFinalAPI()
    }
    else {
      this.uploadImages()
    }
  }

  callFinalAPI() {

    this.request = {
      "checklist_type_id": 2,
      "username": this.access['username'],
      "total_score": this.total_score,
      "risk_score": this.risk_score,
      "signature_img_custodian1":this.signatureImage_custodian1,
      "signature_img_custodian2":this.signatureImage_custodian2,
      "signature_img_auditor":this.signatureImage_auditor, 
      "is_delete":0,
      "location_name": this.location_name,
      "audit_done_by": this.audit_done_by,
      "date_of_audit": this.date_of_audit,
      "route_number": this.route_number,
      "route_start_time": this.route_start_time,
      "route_end_time": this.route_end_time,
      "vehicle_number": this.vehicle_number,
      "own": this.own,
      "name_agency": this.name_agency,
      "name_driver": this.name_driver,
      "name_cust1": this.name_cust1,
      "emp_id1": this.emp_id1,
      "name_cust2": this.name_cust2,
      "emp_id2": this.emp_id2,
      "name_guard1": this.name_guard1,
      "name_guard2": this.name_guard2,
      "number_of_guards": this.number_of_guards,
      "comments": this.comments,
      "f8c1_rs": this.f8c1,
      "f8c1_rr": this.rating21,
      "f8c2_rs": this.switch1,
      "f8c2_rr": this.rating1,
      "f8c3_rs": this.switch2,
      "f8c3_rr": this.rating2,
      "f8c4_rs": this.switch3,
      "f8c4_rr": this.rating3,
      "f8c5_rs": this.switch4,
      "f8c5_rr": this.rating4,
      "f8c6_rs": this.switch5,
      "f8c6_rr": this.rating5,
      "f8c7_rs": this.switch6,
      "f8c7_rr": this.rating6,
      "f9c1_rs": this.switch7,
      "f9c1_rr": this.rating7,
      "f9c2_rs": this.switch8,
      "f9c2_rr": this.rating8,
      "f9c3_rs": this.switch9,
      "f9c3_rr": this.rating9,
      "f9c4_rs": this.switch10,
      "f9c4_rr": this.rating10,
      "f9c5_rs": this.switch11,
      "f9c5_rr": this.rating11,
      "f9c6_rs": this.switch12,
      "f9c6_rr": this.rating12,
      "f9c7_rs": this.switch13,
      "f9c7_rr": this.rating13,
      "f10c1_rs": this.f10c1,
      "f10c1_rr": this.rating22,
      "f10c2_rs": this.switch14,
      "f10c2_rr": this.rating14,
      "f10c3_rs": this.switch15,
      "f10c3_rr": this.rating15,
      "f10c4_rs": this.switch16,
      "f10c4_rr": this.rating16,
      "f10c5_rs": this.switch17,
      "f10c5_rr": this.rating17,
      "f11c1_rs": this.switch18,
      "f11c1_rr": this.rating18,
      "f11c2_rs": this.switch19,
      "f11c2_rr": this.rating19,
      "f11c3_rs": this.switch20,
      "f11c3_rr": this.rating20,
      "chk_zone": this.access['zone'],
      "chk_region": this.access['region'],
      "chk_location": this.access['location'],
      "lat_stamp": this.lat_stamp,
      "long_stamp": this.long_stamp,
      "images": this.image_names
    }

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Frame-Options': 'DENY'
      })
    };

    if (this.server_name) {
      this.http.post(this.service_name, this.request, httpOptions)
        .catch(error => {
          alert("Could not connect to the server. Retry after some time.")
          return EMPTY
        })
        .subscribe(data => {
          this.response = data
         // console.log(this.response)
          alert("Submitted checklist ID is"+this.response.checklist_id)
          this.serviceCalled()
        });
    }

  }

  serviceCalled() {


    if (this.response['status'] && this.response['status'] == "Success") {
      this.sent_to_server = true
    }
    else {

      this.sent_to_server = false
    }

    if (this.sent_to_server) {
      this.deleteLocal()
      setTimeout(() => {
        this.router.navigateByUrl('/', { skipLocationChange: false }).then(() =>
          this.router.navigate(["/history"]));
      },
        2000);
    }
    else {
      this.error_sending = true
    }
  }

  calculateRatings() {
    if (this.switch1) this.rating1 = 1
    else this.rating1 = 3
    if (this.switch2) this.rating2 = 1
    else this.rating2 = 2
    if (this.switch3) this.rating3 = 1
    else this.rating3 = 2
    if (this.switch4) this.rating4 = 1
    else this.rating4 = 2
    if (this.switch5) this.rating5 = 1
    else this.rating5 = 2
    if (this.switch6) this.rating6 = 1
    else this.rating6 = 2
    if (this.switch7) this.rating7 = 1
    else this.rating7 = 3
    if (this.switch8) this.rating8 = 1
    else this.rating8 = 3
    if (this.switch9) this.rating9 = 1
    else this.rating9 = 3
    if (this.switch10) this.rating10 = 1
    else this.rating10 = 3
    if (this.switch11) this.rating11 = 3
    else this.rating11 = 1
    if (this.switch12) this.rating12 = 3
    else this.rating12 = 1
    if (this.switch13) this.rating13 = 3
    else this.rating13 = 1
    if (this.switch14) this.rating14 = 0
    else this.rating14 = 0
    if (this.switch15) this.rating15 = 1
    else this.rating15 = 3
    if (this.switch16) this.rating16 = 1
    else this.rating16 = 3
    if (this.switch17) this.rating17 = 3
    else this.rating17 = 1
    if (this.switch18) this.rating18 = 1
    else this.rating18 = 3
    if (this.switch19) this.rating19 = 1
    else this.rating19 = 3
    if (this.switch20) this.rating20 = 1
    else this.rating20 = 3
    if (this.f8c1 == 'Less than 5 years') this.rating21 = 1
    else if (this.f8c1 == '5 to 15 years') this.rating21 = 2
    else if (this.f8c1 == 'Above 15 years') this.rating21 = 3
    else this.rating21 = 0
    if (this.f10c1 == 'Upto INR 10 Lakhs') this.rating22 = 1
    else if (this.f10c1 == 'INR 10 Lakhs upto 50 Lakhs') this.rating22 = 2
    else if (this.f10c1 == 'Above INR 50 Lakhs') this.rating22 = 3
    else this.rating22 = 0

    this.total_score = this.rating1 + this.rating2 + this.rating3 + this.rating4 + this.rating5 + this.rating6 + this.rating7 + this.rating8 + this.rating9 + this.rating10 + this.rating11 + this.rating12 + this.rating13 + this.rating14 + this.rating15 + this.rating16 + this.rating17 + this.rating18 + this.rating19 + this.rating20 + this.rating21 + this.rating22

    if (this.total_score >= 45) this.risk_score = "High"
    else if (this.total_score >= 35) this.risk_score = "Medium"
    else if (this.total_score >= 17) this.risk_score = "Low"
    else this.risk_score = "None"

  }

  checkGeneralData() {

    if (this.location_name && this.audit_done_by && this.date_of_audit && this.route_number && this.route_start_time && this.route_end_time && this.vehicle_number && this.own && this.name_driver && this.name_cust1 && this.name_cust2 && this.access['location'] && this.access['region'] && this.access['zone']) {

      if (this.number_of_guards == 0) this.all_data = true
      else if (this.number_of_guards == 1 && this.name_guard1) this.all_data = true
      else if (this.number_of_guards == 1 && !this.name_guard1) this.all_data = false
      else if (this.number_of_guards == 2 && this.name_guard1 && this.name_guard2) this.all_data = true
      else if (this.number_of_guards == 2 && this.name_guard1 && !this.name_guard2) this.all_data = false
      else if (this.number_of_guards == 2 && !this.name_guard1 && this.name_guard2) this.all_data = false
      else if (this.number_of_guards == 2 && !this.name_guard1 && !this.name_guard2) this.all_data = false
      else if (this.number_of_guards > 2 && (!this.name_guard1 || !this.name_guard2)) this.all_data = false
      else this.all_data = true

    }
    else {
      this.all_data = false
    }
  }


  scrollTop() {
    var pageTop = document.querySelector('#pagetop');
    pageTop.scrollIntoView();
  }

  wait(ms: number) {
    var start = new Date().getTime();
    var end = start;
    while (end < start + ms) {
      end = new Date().getTime();
    }
  }

  checkIfStarted() {
    if ((this.all_fleet || this.all_crew || this.all_operations || this.all_reporting || this.all_data) && !this.sent_to_server) {
      return true
    }
    else {
      return false
    }
  }

  getLocation() {
    navigator.geolocation.getCurrentPosition((pos) => this.setPosition(pos))
  }

  setPosition(position) {
    this.lat_stamp = position.coords.latitude;
    this.long_stamp = position.coords.longitude;
  }


}
