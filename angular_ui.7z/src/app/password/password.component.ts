import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { retry } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/add/operator/catch';
import { EMPTY } from 'rxjs';
import { RecursiveTemplateAstVisitor } from '@angular/compiler';

declare const $: any;

@Component({
  selector: 'app-password',
  templateUrl: './password.component.html',
  styleUrls: ['./password.component.scss']
})
export class PasswordComponent implements OnInit {

  server_json: any
  server_name: string
  service_name: string

  request: any
  response: any

  login_token: any
  access: any

  invalid_user: boolean = false
  old_pass: boolean = false
  changed: boolean = false

  emp_id: any
  new_pass1: any
  new_pass2: any

  constructor(private router: Router, private http: HttpClient) { }

  ngOnInit() {

    this.server_json = require('./../../../config.json');
    this.server_name = this.server_json['server'];
    this.service_name = this.server_name.concat('/password')


    this.login_token = localStorage.getItem('CMSAppUserLogin');

    if (this.login_token) {
      this.access = JSON.parse(this.login_token);
      this.access['password'] = true
    }
    else {
      this.router.navigateByUrl('/', { skipLocationChange: false }).then(() =>
        this.router.navigate(["/login"]));
    }

  }

  resetPass() {
    this.invalid_user = false
    this.old_pass = false
    this.changed = false

    if (this.new_pass1 == this.new_pass2) {
      this.new_pass1 = btoa(this.new_pass1)
      this.new_pass2 = btoa(this.new_pass2)

      if (this.access['type'] != "admin") {
        this.request = { "emp_id": this.access['emp_id'], "new_password": this.new_pass2 }
      }
      else {
        this.request = { "emp_id": this.emp_id, "new_password": this.new_pass2 }
      }

      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'X-Frame-Options': 'DENY'
        })
      };

      this.http.post(this.service_name, this.request, httpOptions)
        .catch(error => {
          alert("Could not connect to the server. Retry after some time.")
          return EMPTY
        })
        .subscribe(data => {
          this.response = data
          this.new_pass1 = null
          this.new_pass2 = null
          this.serviceCalled()
        });
    }
    else {
      alert("Passwords do not match.")
      this.new_pass1 = null
      this.new_pass2 = null
    }

  }

  serviceCalled() {
    if (this.response['status'] && this.response['status'] == "Success") {
      this.changed = true
    }
    else if (this.response['status'] && this.response['status'] == "Same") {
      this.old_pass = true
    }
    else {
      this.invalid_user = true
    }
  }

  isMobileMenu() {
    if ($(window).width() > 991) {
      return false;
    }
    return true;
  };

}
