import { Component, OnInit, ViewChild, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { Angular5Csv } from 'angular5-csv/dist/Angular5-csv';
declare const $: any;

import { retry } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/add/operator/catch';
import { EMPTY } from 'rxjs';
import { strict } from 'assert';

import * as jspdf from 'jspdf';
import * as _html2canvas from "html2canvas";
import { BsDatepickerDirective, BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { parseDate } from 'ngx-bootstrap/chronos/public_api';






@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.css']
})
export class HistoryComponent implements OnInit {
  @ViewChild(BsDatepickerDirective) datepicker: BsDatepickerDirective;
  datepickerconfig:Partial<BsDatepickerConfig>;
  colorTheme: string ='theme-dark-blue';

  @HostListener('window:scroll',['$event'])
  onScrollEvent() {
    this.datepicker.hide();
  }

  server_json: any
  server_name: string
  service_name: string
  service_name_checklist: string
  service_name_demographic: string
  service_name_image: string
  service_name_delete: string

  username: string = null
  checklist_type: string = null
  risk_score: string = null
  zone: string = null
  region: string = null
  location: string = null
  sign_url: string =null
  sign_url2: string =null
  sign_url3: string =null
  type_audit: string = null
  type_user : any
  chk_id:any

  request: any
  response: any
  audits: any
  from_date:any =null
  to_date:any =null
  request2: any
  response2: any
  chk_data: any
  chk_resp: any
  chk_cash: any
  chk_img: any

  request3: any
  response3: any
  zones: any
  regions: any
  locations: any

  request_img: any
  response_img: any

  got_history: boolean = false
  got_checklist: boolean = false
  checklist_mode: boolean = false

  date: Date = new Date()

  login_token: any
  logo:String
  access: any

  p: number = 1
   html2canvas: any = _html2canvas;
  demographic: string=null;
  hzone :string=null;
  hregion:string=null;
  auditor_name:string=null;
  cust_1_name:string=null;
  cust_2_name=null

  popoverTitle = 'Record Delete Confirmation';
  popoverMessage = 'Are you sure ?';
  confirmClicked = false;
  cancelClicked = false;
 







  constructor(private router: Router, private http: HttpClient) { 
    this.datepickerconfig = Object.assign({},{
      containerClass: this.colorTheme,
      dateInputFormat:'YYYY-MM-DD' 
    });

   
  }
  

  ngOnInit() {

    this.server_json = require('./../../../config.json');
    this.server_name = this.server_json['server'];
    this.service_name = this.server_name.concat('/history')
    this.service_name_checklist = this.server_name.concat('/checklist')
    this.service_name_demographic = this.server_name.concat('/demographic')
    this.service_name_image = this.server_name.concat('/image-download')
    this.service_name_delete=this.server_name.concat('/delete-checklist')

    this.login_token = localStorage.getItem('CMSAppUserLogin');

    if (this.login_token) {
      this.access = JSON.parse(this.login_token);
      this.access['history'] = true
    }
    else {
      this.router.navigateByUrl('/', { skipLocationChange: false }).then(() =>
        this.router.navigate(["/login"]));
    }

    if (this.access['type'] == "auditor") {
      this.username = this.access['username']
    }
    else {
      this.username = null
    }
    this.type_user = this.access['type']
    console.log(this.type_user)
    this.getDemographicFilter(this.zone, this.region, this.location)
    this.showAudits()
    //this.logo ="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4QBoRXhpZgAASUkqAAgAAAADABIBAwABAAAAAQAAADEBAgAQAAAAMgAAAGmHBAABAAAAQgAAAAAAAABTaG90d2VsbCAwLjI4LjQAAgACoAkAAQAAAL4AAAADoAkAAQAAADcAAAAAAAAA/+EJ8mh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8APD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNC40LjAtRXhpdjIiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczpleGlmPSJodHRwOi8vbnMuYWRvYmUuY29tL2V4aWYvMS4wLyIgeG1sbnM6dGlmZj0iaHR0cDovL25zLmFkb2JlLmNvbS90aWZmLzEuMC8iIGV4aWY6UGl4ZWxYRGltZW5zaW9uPSIxOTAiIGV4aWY6UGl4ZWxZRGltZW5zaW9uPSI1NSIgdGlmZjpJbWFnZVdpZHRoPSIxOTAiIHRpZmY6SW1hZ2VIZWlnaHQ9IjU1IiB0aWZmOk9yaWVudGF0aW9uPSIxIi8+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPD94cGFja2V0IGVuZD0idyI/Pv/bAEMAAwICAwICAwMDAwQDAwQFCAUFBAQFCgcHBggMCgwMCwoLCw0OEhANDhEOCwsQFhARExQVFRUMDxcYFhQYEhQVFP/bAEMBAwQEBQQFCQUFCRQNCw0UFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFP/AABEIADcAvgMBIgACEQEDEQH/xAAfAAABBQEBAQEBAQAAAAAAAAAAAQIDBAUGBwgJCgv/xAC1EAACAQMDAgQDBQUEBAAAAX0BAgMABBEFEiExQQYTUWEHInEUMoGRoQgjQrHBFVLR8CQzYnKCCQoWFxgZGiUmJygpKjQ1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4eLj5OXm5+jp6vHy8/T19vf4+fr/xAAfAQADAQEBAQEBAQEBAAAAAAAAAQIDBAUGBwgJCgv/xAC1EQACAQIEBAMEBwUEBAABAncAAQIDEQQFITEGEkFRB2FxEyIygQgUQpGhscEJIzNS8BVictEKFiQ04SXxFxgZGiYnKCkqNTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqCg4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2dri4+Tl5ufo6ery8/T19vf4+fr/2gAMAwEAAhEDEQA/AP1TopM0ZoAWikyKMildALTJW2j0p2a5n4jeN9I+Hfg/UvEOuXIttNsYjLIerPjoijuxOAB3z6VSTk1GO4m7K50EUyycBt3fIHFPbGcV+WR/bC+J5+IGs+J7HXHsLbUZAItGmxPbQRKfkVVIyDjqwIJLHntXqUHxy/aP+J+kMui6FJb28qYF7p2lNCCPVZJmdc/QfTFd9bBSoO8mj0cJgqmLeslFeZ9p+M/iT4X+HtqLjxDrVlpMbcp9qmCl/ZV6sfYZrzmz/bJ+E99qS2a+KEgkZgokuYJYYs57uygAd8k4ABJNfnj8QvB/jPw/qUupeMNF1m3u5W3S3+pxOQz84/esGU/Tf9MV3P7KPwEl+OPjNL7VIC3hHS2E11uXb9rlJBWHkYZDj5sdgR3rhbs7I/VaPBmWUMqqZjjMRdRX2WrX7ebP08tbtLyBJonEkcihkZTkEHkEHuKsLnI71XtLMWqLGiqkUahI1UYAAGMVZUYPtQ7H4y/ib+70HUUUVIwooooAKKKKACiiigAooooAKKKKAGFwAOevtXlni79qr4P+BdXm0nXviV4Z03U4Dtms5dTiMsR9HUElT7GvlT/gqV+0d4l8C6X4a+F3gq7mstd8WhnvZbR9s5t94iSFGyNvmvlSc/dVh35n+Dn/AASU+G+ieELUePrjUvE/iaZEe8ktr6S0topCMskQj2swBJ+ZySSScLnj0IYalGmquIbSe1gPr7wZ8c/h58RNPvL3wx420HXrazjM109hqEUpt0AyWkCnKDHOWxxzVn4e/GDwT8WIbybwb4q0nxNFZsqXDaXdJP5RPI3bScZwcfSvFvAH7HHw7/Ze8E/ErUPCFpcm91nS7lXn1KYTvbwLC5EEbbQwQtlyDkk4yTtXH5Kfsn/GfxV+zB4tsPibYWVzP4Pa7XRdbgQjyroMpkMJG4YlVEMkbEdUwTgtWlDAxxMZui9F3A/oCM6KpYsAoGc9sV5NJ4x+D/7S1rqHhSHXPD3jqGzZbi7sLa6WfydrFVkO08YbPOa+UP27f23bbU/APh34f/CLUjrfifx9axOLrTz+9tbKbCrGMZImm+ZcDlF3McfKa8q/4I+addaD8Xvipp1zEIru30yG3njVslZEuGUgbSVY5DZIyOMjIpQwNSFCVaTtJCaT0Pt3V7b9nj9nHULdNYk8H+DtQnXfCuqTxi5KjoVEhLbR6jjNdv4B/aH+F3xL1BdP8JeP/D2vagwO2ysNRiknYAZJWPO449hivyN+CVh8M/ir+1f49b9pnV7iwvri5nEUd/cy2cDXazEGKaVSDGEiACfMi9RkkDP6U/s+/smfAf4aeKn8efDCytru8e2exjvINYk1KGBSVLbC8jhW+UDOcgZHQmrxOHhTipVHJytp2KcpS93ofQWraNZa9YvZ39tHeWkylZIJlBDA+oIrN8DeAtC+HOhwaJ4c0yDSdOjLSC2twQoZm3MeeuSa3kGAgADAj7w7fjUoATBJ6Dr7V5bemparVeT2bb5Xra+lx46UtNDAnGefelzzjn8qkzFopMijNAC0UzzVwTngdfanBgehzxmgBaKTcB3pFkVuh564IwaAHUU0OD0z+VLmgBaKTNGaAFopM0Bgc47UAfl//wAFaPBur+FPiZ8L/jHp1sbu00wRafO7r8kU0FybiDfns5eQenyDJ5Gftz4J/tVfDj44+F7XWdE8S2FvPLEjXOkX1ykN5ZykfNHJEWyOeARkNgkEivRvF/gvRvHvhy+0HxDpdtrGj38ZjubO6XfHIPoehzg5GCCM9a+LPFH/AAR7+EOtavLeaXrHifw5bFsrYWl3FPEvJOA00bPjnux/GvQ9rQr0VTq3Tjt2GfXXxB1zTNY+HPjKKz1C1u2h0m6EyQzK3l5hf72DxX5y/wDBLf4VaF8bv2b/AIu+D/E9mLjSdR1G3jYg/vIn+z5SZDztkUhWVuxFfdXwR/ZY8IfAb4QXvw98Oxzrp9+ky3uoTeWbu6aVSpeRggBZVwo4wAOlRfswfsn+FP2U9D1rS/Ct7ql/BqtwlzM+qyxuysibQF2IoAx7UqdaNGlOEHrdWEfNv7DX/BOy8+APxB13xl48Nhq2r2M72fh0Wxyiw4Ia8Yc7XcNgL1QbzyWGPNv+CXJQftL/AB1JcoCZDIZCB/y/y4PB4P0OAcV+ojoSuBwa8D+Av7Gvg/8AZ28ceK/FXhu/1i71HxHn7XFfzRNECZTLlNqKw5YjlsY/MWsZKUJqo9WhnO/F39mH9nj9ofxfrMWvQaO/jWzkCajc6PqS2l+km1WUTrGQHbYU5kViBjnpX54654f/AOGM/wBuHw1oXwh8XXXiKxuLyzWayjmEjlZpdklrceX8kh2ksGxkbsnG019s/E7/AIJRfCT4leJNQ19b/wAS6DqWoXDXV2bXUBcpLK5zIxNwsjncSTy3UntxXZ/s8f8ABOv4V/s6+I4PEemx6h4i8SWwYW2pa1Kjm23YyY40VUBwMBiCRzzzXRSxFGjFp1HK62aEfT8eOOmcdqSZ2RPlxn1JxTlUgDjAHGKJFLLtGRnuO1eJ6gebaB8TtR1pG186FbWXgVkklTW7rUwkwhTeTdNAybUgZV3K3mlyGBZF5xfX42+FFjy91ewz+bDEtnNpd0ly/neYYXWExeYyv5UuGCkZjcZypxnf8KOtX0+90OXXNVk8HXkFzbS+Gi8ItlSdXWRA4iEpjxI21N4VcDAwqgS6f8F4LfWbXWNQ1vVNb1W1mhkhubx4k2xwrOsUOyKNEIH2mZi+3eSwyxCqq7e71Atv8cfBmyFv7UnKSxJO7pYXJFvG0rwhpiI/3P72ORCJNpDIwONpqSb4x+EUlvlk1OSP7ALgtK9rMI5DDIIZRE2zbMyyuse2MsdzAAZqkfgdoraX4hsDLcmDXIpYbgll3IJLu5ujsIHGJLuQAHPyqvfOcW0/Zj8LWup61foHik1F5J0MFraxT2sr3AuDIlwsQlYiUBlV3ZRgDGBRan5gaup/G7SbTXNP0pLHVxcXllfXiPdadcwRw/ZjCrLNmPcgPnAhyNuAeTmrOj/HDwlqF+9kdVRbpGWOaUW8wtY5TZpeeX9oZAmfs7rLgkHaQcUy7+Dz6nJp1xqXijVtQvraC7s5bqRLZWuLe4EfmQlViCIoMMTAqobKdeTmuPgLoY0m909jNdW13frqEkV2ytGzpYpZLGwCgmMxxgkAqdxJBAOAfuwOj8N/EnQ/GN9JYaZcXP22O2jvWgurGe2fyJCwSQCVFypKsAR6H0rB0D4karrs41WHQIYPBjSTRrrFzqSrOY42ZTc+Rt2iBtuUYSlyGUsi84g+G3wx13wxr2oatresHUXksLfTLa2NxLOscULyOGZpP4m8wKcKWwgLySnaVsw/Be2gN5Yrr2rjwvdG4aTw8Xh+zAT7zIgfy/NEeZHIj37VBCqFRQtL3QLUXxs8JPbGUXl6nzQKkDabdCaQTlhA6RmPe6uUcBlBBKsM5BxXtvj/AOB7uxnvE1a4W2igluN76dcp5iRSrFL5YaMGRkkdEZUyylgCBmmaR8GYbXUbfUNU17Vtd1C1e3FvcXrQho4YSzJEPLjUEbnYs5G9sDJOBSXXwL0S7tLO3kuL7ZbfbSuyROTdXsV5Jn5e0sK7cdBkHNO1PzAs2Px18GX2oTWa6pNBPDLLby/bbCe3WGaOD7Q8TtJGoRxB+92MQTH84BXmlm+Ovg22jg87UriGWe6js4rZ9PuVuJJZIpJowsRj3kNHFKwYDB2MAcgima18E/D/AIhj1uDUEubqy1nUJtQvbN5gIpTLp/2CRMBfuGHLYzneScgcDL8Gfs8aD4JutLubSTdc6bf/AG+CaOwtLUsRa3FqqyeRFHvwlzKcnkkjBA+Wj92B0B+MHhnbMVursqjbEf8As65KTt5gi2wt5eJjvYDEZY856c10PhrxRpvi3S01DS7kXVszyRM2xkZJI3MckbqwDK6urKysAQQQRXnN/wDs8abq3h2Xw/e6rfXnh6Nkl03S7uC0mi051fzFKh4WEmDlcS7wFJHOcjuvAngqy8A+GrPRbAIttb7yBHbw26lncuxEcKJGuWYn5VHUk5JJqXyW0A6KiiioAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD/9k="



  }
  
  covertTobase64(url){
    console.log("inside url"+url);
   var image = new Image();
    //image.crossOrigin ='Anonymous';
    image.setAttribute('crossOrigin', 'anonymous');
    image.src = url;
    image.onload = function () {
      console.log("inside onload");

    var canvas = document.createElement("canvas");
    canvas.width = 80;
    canvas.height = 80;

    var ctx = canvas.getContext("2d");
    ctx.drawImage(url, 0, 0);

    var dataURL = canvas.toDataURL("image/png");
     console.log("Data URL");
     console.log(dataURL);
     console.log("BAse 64--->>");
     console.log(dataURL.replace(/^data:image\/(png|jpg);base64,/, ""));
     return(dataURL.replace(/^data:image\/(png|jpg);base64,/, ""));
  }
}
 
  convertTocashPdf(){
    console.log("inside convert to pdf")
    var report = document.getElementById('cash-data');
   this.html2canvas(report).then(canvas =>{
      var pageWidth = 210;
      var pageHeight = 297;
      var reportHeight = canvas.height*pagetWidth/canvas.width;
      var pagetWidth = pageHeight;
      const reportDataURL = canvas.toDataURL('image/png');
      let pdf = new jspdf('p','mm','legal');
      var position =10;
      pdf.addImage(reportDataURL,'PNG',3,position,pageWidth,pageHeight);
      pdf.setFont("arial");
      pdf.setFontStyle('normal');
      pdf.setFontSize(10)
      pdf.text(105,20,this.type_audit+" "+" Audit Report");
     // pdf.addImage(this.logo,105,0)
      pdf.text(5,350,'this data is according to the best of your knowledge this report is auto genarated and there is nothing we can change');
      if(this.sign_url!=''){
        pdf.addImage(this.sign_url,'PNG',6,315);
        pdf.text(14,345,this.auditor_name)

      }
     
     
      if(this.sign_url2!=''){
        pdf.addImage(this.sign_url2,'PNG',75,315)
        pdf.text(75,345,this.cust_1_name)

      }
      if(this.sign_url3!=''){
        pdf.addImage(this.sign_url3,'PNG',130,315)
        pdf.text(130,345,this.cust_2_name)
      }
     
     
      pdf.save('audit-data.pdf')
    });
  }

  convertToPdf(){
    console.log("inside convert to pdf")
   //var url ="";
 // var img= this.covertTobase64(url)
  var report = document.getElementById('historyData');
   this.html2canvas(report).then(canvas =>{
      var pageWidth = 210;
      var pageHeight = 297;
      var reportHeight = canvas.height*pagetWidth/canvas.width;
      var pagetWidth = pageHeight;
      const reportDataURL = canvas.toDataURL('image/png');
      let pdf = new jspdf('p','mm','legal');
      var position =10;
      pdf.addImage(reportDataURL,'PNG',3,position,pageWidth,pageHeight);
      pdf.setFont("arial");
      pdf.setFontStyle('normal');
      pdf.setFontSize(10)
     // pdf.addImage(this.logo,105,0)
      pdf.text(105,20,this.type_audit+" "+"Report");
      pdf.text(5,350,'this data is according to the best of your knowledge this report is auto genarated and there is nothing we can change');
      if(this.sign_url!=''){
        pdf.addImage(this.sign_url,'PNG',6,315);
        pdf.text(10,345,this.auditor_name)
      }
     
      if(this.sign_url2!=''){
        pdf.addImage(this.sign_url2,'PNG',75,315)
        pdf.text(75,345,this.cust_1_name)
      }
      
      if(this.sign_url3!=''){
        pdf.addImage(this.sign_url3,'PNG',130,315)
        pdf.text(130,345,this.cust_2_name)
      }
    //   pdf.addPage("p");
    //   pdf.text(5,350,'this data is according to the best of your knowledge this report is auto genarated and there is nothing we can change');
    //  // url = this.sign_url
    // // pdf.addImage(this.sign_url,'PNG',1,2);
     
    //   pdf.setPage(1);
      // var image = new Image();
      // image.src=toBase64String("C:/Users/ashutosh.mishra-v/Pictures/idrcmlive.png");
      
     

      pdf.save('audit-data.pdf')
    });
  }

 

  delete_checklist(chk_id){

   let flag= confirm("Are you sure")

   if (flag){
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Frame-Options': 'DENY'
      })
    };

    this.http.post(this.service_name_delete, {"checklist_id":chk_id}, httpOptions)
      .catch(error => {
        alert("Could not connect to the server. Retry after some time.")
        return EMPTY
      })
      .subscribe(data => {
        this.response = data
        this.notify_deleted()
      });

   }
   

  }
  notify_deleted(){
    if (this.response['status'] && this.response['status'] == "Success") {
      alert("data deleted successfully")
      this.ngOnInit()

    }
    else {
      alert("please enter correct checklist ID")
      
    }

  }


  showAudits() {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Frame-Options': 'DENY'
      })
    };

    this.request = { 'username': this.username, 'checklist_type': this.checklist_type, 'risk_score': this.risk_score, 'zone': this.zone, 'region': this.region, 'location': this.location ,'from_date':this.from_date,'to_date':this.to_date}
    this.http.post(this.service_name, this.request, httpOptions)
      .catch(error => {
        alert("Could not connect to the server. Retry after some time.")
        return EMPTY
      })
      .subscribe(data => {
        this.response = data
        console.log(this.response)
        this.serviceCalled()
      });

  }
  serviceCalled() {
    if (this.response['status'] && this.response['status'] == "Success") {
      this.got_history = true
    }
    else {
      this.got_history = false
    }
    this.audits = this.response['data']
  }

  showChecklist(cid) {
    this.checklist_mode = true
    this.request2 = { 'checklist_id': cid }

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Frame-Options': 'DENY'
      })
    };

    this.http.post(this.service_name_checklist, this.request2, httpOptions)
      .catch(error => {
        alert("Could not connect to the server. Retry after some time.")
        return EMPTY
      })
      .subscribe(data => {
        this.response2 = data
        if(this.response2.data.signature1!=''){
          this.sign_url=(this.response2.data.signature1.replace(/'/g, "")).substr(1);
        }
        
        if(this.response2.data.signature2!=''){
          this.sign_url2=(this.response2.data.signature2.replace(/'/g, "")).substr(1);
        }
       
        if(this.response2.data.signature3!=''){
          this.sign_url3=(this.response2.data.signature3.replace(/'/g, "")).substr(1);
        }
       
        this.type_audit=(this.response2.data.checklist_type);
        this.demographic =this.response2.data.demographic;
        var place =this.demographic.split('/')
        this.hzone =place[0]
        this.hregion=place[1]
        this.serviceCalled2()
         if(this.type_audit=='Branch'&&this.access['type'] == "supervisor"){
           this.cust_1_name = this.response2.data.branch_manager
           this.cust_2_name =null
         }
         else {
           this.cust_1_name =this.response2.data.name_cust1
           this.cust_2_name =this.response2.data.name_cust2

         }
         this.auditor_name =this.response2.data.audit_done_by.replace(/[0-9]/g, '')
         
        console.log(this.sign_url3)
        console.log(this.cust_1_name,this.cust_2_name,this.auditor_name)
      });

  }
  serviceCalled2() {

    if (this.response['status'] && this.response2['status'] == "Success") {
      this.got_checklist = true
    }
    else {
      this.got_checklist = false
    }
    this.chk_data = this.response2['data']
    this.chk_resp = this.response2['responses']
    this.chk_img = this.response2['images']
    if (this.chk_data['checklist_type'] == "ATM") {
      this.chk_cash = this.response2['cash_count']
    }

  }

  downloadImage(img) {
    console.log("image path is "+img)
    var image = new Image(img);


    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Frame-Options': 'DENY'
      })
    };

    this.request_img = { 'image_name': img }

    this.http.post(this.service_name_image, this.request_img, httpOptions)
      .catch(error => {
        alert("Could not connect to the server. Retry after some time.")
        return EMPTY
      })
      .subscribe(data => {
        if (data['status'] && data['status'] == "Success") {
          this.response_img = data['image']
          window.open(this.response_img, '_blank');
        }
        else {
          alert("Could not retrieve image from the server.")
        }
      });

  }

  getDemographicFilter(zone_name: any, region_name: any, location_name: any) {
    if (!zone_name) {
      this.zone = this.access['zone']
    }
    else {
      this.zone = zone_name
    }
    if (!region_name) {
      this.region = this.access['region']
    }
    else {
      this.region = region_name
    }
    if (!location_name) {
      this.location = this.access['location']
    }
    else {
      this.location = location_name
    }
    this.request3 = { 'username': this.access['username'], 'zone': this.zone, 'region': this.region }

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Frame-Options': 'DENY'
      })
    };

    this.http.post(this.service_name_demographic, this.request3, httpOptions)
      .catch(error => {
        alert("Could not connect to the server. Retry after some time.")
        return EMPTY
      })
      .subscribe(data => {
        this.response3 = data
        if (this.response3['status'] && this.response3['status'] == "Success") {
          this.zones = this.response3['zones']
          this.regions = this.response3['regions']
          this.locations = this.response3['locations']
        }
        else {
          this.got_history = false
        }
        this.showAudits()
      });
  }

  filterChecklistType(ct) {
    this.checklist_type = ct
    this.showAudits()
  }
  filterRiskScore(rs) {
    this.risk_score = rs
    this.showAudits()
  }
  filterDateReport(f_date,t_date){
    this.from_date =f_date
    this.to_date=t_date
    console.log(this.from_date+'&'+this.to_date)
    this.showAudits()
  }


  historyMode() {
    this.router.navigateByUrl('/', { skipLocationChange: false }).then(() =>
      this.router.navigate(["/history"]));
  }

  backToRecent() {
    this.checklist_mode = false
    this.chk_data = null
    this.scrollTop()
  }
  isMobileLogin() {
    if (this.isMobileMenu()) {
      return true
    }
    else {
      return false
    }
  }

  isMobileMenu() {
    if ($(window).width() > 991) {
      return false;
    }
    return true;
  };

  scrollTop() {
    var pageTop = document.querySelector('#pagetop');
    pageTop.scrollIntoView();
  }

  exportAsCsv() {

    var data = this.response['data']
    console.log(data)
    var filename = "Audit History " + ((this.date.getDate() < 10 ? '0' : '') + this.date.getDate()) + '-' + (((this.date.getMonth() + 1) < 10 ? '0' : '') + (this.date.getMonth() + 1)) + '-' + this.date.getFullYear();

    var options = {
      fieldSeparator: ',',
      headers: ["ATM ID/Route ID", "Checklist no.", "Checklist Type", "Comments", "Date", "Date and Time Stamp", "Branch/Location", "Month", "Name of Auditor", "Region", "Risk Score", "Role", "Title", "Total Score", "Username of Auditor", "Zone"]
    };

    new Angular5Csv(data, filename, options);
  }

}
