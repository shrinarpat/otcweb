import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TouchSequence } from 'selenium-webdriver';

import { retry } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/add/operator/catch';
import { EMPTY } from 'rxjs';


declare var $: any;

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.css']
})
export class NotificationsComponent implements OnInit {

  server_json: any
  server_name: string
  service_name: string

  request: any
  response: any

  username: string = null
  password: string = null

  invalid_user: boolean = false

  logged_out: boolean = true
  login_token: any

  constructor(private router: Router, private http: HttpClient) { }

  ngOnInit() {

    this.login_token = localStorage.getItem('CMSAppUserLogin');
    if (this.login_token) {
      this.logged_out = false
    }
    else {
      this.logged_out = true
    }

    this.server_json = require('./../../../config.json');
    this.server_name = this.server_json['server'];

    this.service_name = this.server_name.concat('/login')


    // this.getDemographicFilter(this.zone, this.region, this.location)
  }

  logoutButton() {
    location.href = "./"
    localStorage.clear();
    this.logged_out = true
  }

  loginButton() {

    this.password = btoa(this.password)
    this.request = { 'username': this.username, 'password': this.password }

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Frame-Options': 'DENY'

      })
    };

    this.http.post(this.service_name, this.request, httpOptions)
      .catch(error => {
        alert("Could not connect to the server. Retry after some time.")
        return EMPTY
      })
      .subscribe(data => {
        this.response = data
        this.serviceCalled()
      });

  }

  serviceCalled() {
    if (this.response['status'] && this.response['status'] == "Success") {
      this.invalid_user = false
      this.response['date_time'] = this.currentDateTime()
      var access_json = JSON.stringify(this.response)
      console.log(access_json)
      localStorage.setItem('CMSAppUserLogin', access_json)

      location.href = "./"
    }
    else {
      this.invalid_user = true
    }
  }


  registerButton() {
    this.router.navigateByUrl('/register')
  }


  isMobileMenu() {
    if ($(window).width() > 991) {
      return false;
    }
    return true;
  }

  currentDateTime() {
    var now = new Date();
    var year = "" + now.getFullYear();
    var month = "" + (now.getMonth() + 1); if (month.length == 1) { month = "0" + month; }
    var day = "" + now.getDate(); if (day.length == 1) { day = "0" + day; }
    var hour = "" + now.getHours(); if (hour.length == 1) { hour = "0" + hour; }
    var minute = "" + now.getMinutes(); if (minute.length == 1) { minute = "0" + minute; }
    var second = "" + now.getSeconds(); if (second.length == 1) { second = "0" + second; }
    return year + "-" + month + "-" + day + " " + hour + ":" + minute + ":" + second;
  }

  contactAdmin() {
    alert('Please contact the Administrator for a new default password.')
  }
}
