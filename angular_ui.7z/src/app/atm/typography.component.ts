import { Component, OnInit, ViewChild, HostListener } from '@angular/core';
import { NgModule } from '@angular/core';

import { Router } from '@angular/router';


import { retry } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/add/operator/catch';
import { EMPTY } from 'rxjs';

import { Injectable } from '@angular/core';
import { CanDeactivate } from '@angular/router';

import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { WebcamImage, WebcamInitError, WebcamUtil } from 'ngx-webcam';
import { SignaturePad } from 'angular2-signaturepad/signature-pad';
import { BsDatepickerDirective, BsDatepickerConfig } from 'ngx-bootstrap/datepicker';








@Injectable()
export class ConfirmDeactivateGuard2 implements CanDeactivate<TypographyComponent> {

  canDeactivate(target: TypographyComponent) {
    if (target.checkIfStarted()) {
      return window.confirm('Are you sure?');
    }
    return true;
  }

}
@NgModule({
  providers: [
    ConfirmDeactivateGuard2
  ]
})


@Component({
  selector: 'app-typography',
  templateUrl: './typography.component.html',
  styleUrls: ['./typography.component.css']
})
export class TypographyComponent implements OnInit {
  @ViewChild(BsDatepickerDirective) datepicker: BsDatepickerDirective;
  datepickerconfig:Partial<BsDatepickerConfig>;

  @HostListener('window:scroll',['$event'])
  onScrollEvent() {
    this.datepicker.hide();
  }

  @ViewChild('signpad1') signaturePad: SignaturePad;
  @ViewChild('signpad2') signaturePad2: SignaturePad;
  @ViewChild('signpad3') signaturePad3: SignaturePad;
 
  private signaturePadOptions:  object= { // passed through to szimek/signature_pad constructor
    'minWidth': .5,
    penColor:'rgb(7, 8, 7)',
    backgroundColor:'rgb(255,255,255)',
    'canvasWidth': 400,
    'canvasHeight': 100
    
  };


  public showWebcam = true;
  public allowCameraSwitch = true;
  public multipleWebcamsAvailable = false;
  public deviceId: string;
  public videoOptions: MediaTrackConstraints = {
    // width: {ideal: 1024},
    // height: {ideal: 576}
  };
  public errors: WebcamInitError[] = [];

  // latest snapshot
  public webcamImage: WebcamImage = null;
  public webcamImageArr: any = []

  // webcam snapshot trigger
  private trigger: Subject<void> = new Subject<void>();
  // switch to next / previous / specific webcam; true/false: forward/backwards, string: deviceId
  private nextWebcam: Subject<boolean | string> = new Subject<boolean | string>();

  request_img: any = []
  response_img: any = null 
  signatureImage_custodian1: any= null;
  signatureImage_custodian2: any= null;
  signatureImage_auditor: any= null;
  selectedDate:any
  colorTheme: string='theme-dark-blue'
  bsInlineValue : Date= new  Date();



  image_names: string = null
  date_img: any = null


  server_json: any
  server_name: string
  service_name: string

  request: any
  response: any

  response_datetime: any
  response_custodian: any
  response_atm_master: any
  response_audit_type: any

  service_name_datetime: any
  service_name_custodian: any

  service_name_atm_master: any
  atm_id_list: any = []
  msp_list: any = []
  bank_list: any = []

  service_name_type_audit: string
  service_name_type_discrepency: string
  service_name_type_sortage: string
  checklist_name :any 
  checklist_dis_name :any
  checklist_sort_name :any
  cbr:any

  service_name_loc: string
  service_name_atm: string
  service_name_bank: string

  reponse2:any
  reponse3:any 
  region1:string
  zone1:string 
  msp:string
  locations: any
  regions: any
  zones: any
  

  login_token: any
  access: any

  review_mode: boolean = false
  incomplete: boolean = false
  cash_flag:boolean=false

  atm_cs_2000: number = 0
  atm_cs_500: number = 0
  atm_cs_200: number = 0
  atm_cs_100: number = 0
  atm_cs_50: number = 0
  atm_cs_20: number = 0
  atm_cs_10: number = 0

  atm_pb_2000: number = 0
  atm_pb_500: number = 0
  atm_pb_200: number = 0
  atm_pb_100: number = 0
  atm_pb_50: number = 0
  atm_pb_20: number = 0
  atm_pb_10: number = 0

  atm_oc_2000: number = 0
  atm_oc_500: number = 0
  atm_oc_200: number = 0
  atm_oc_100: number = 0
  atm_oc_50: number = 0
  atm_oc_20: number = 0
  atm_oc_10: number = 0

  pc_2000: number = 0
  pc_500: number = 0
  pc_200: number = 0
  pc_100: number = 0
  pc_50: number = 0
  pc_20: number = 0
  pc_10: number = 0
  
  sc_2000: number = 0
  sc_500: number = 0
  sc_200: number = 0
  sc_100: number = 0
  sc_50: number = 0
  sc_20: number = 0
  sc_10: number = 0

  mc_2000: number = 0
  mc_500: number = 0
  mc_200: number = 0
  mc_100: number = 0
  mc_50: number = 0
  mc_20: number = 0
  mc_10: number = 0

  os_2000: number = 0
  os_500: number = 0
  os_200: number = 0
  os_100: number = 0
  os_50: number = 0
  os_20: number = 0
  os_10: number =0

  tn_2000: number = 0
  tn_500: number = 0
  tn_200: number = 0
  tn_100: number = 0
  tn_50: number = 0
  tn_20: number = 0
  tn_10: number = 0

  nil_2000: number = 0
  nil_500: number = 0
  nil_200: number = 0
  nil_100: number = 0
  nil_50: number = 0
  nil_20: number = 0
  nil_10: number = 0

  tov_2000: number = 0
  tov_500: number = 0
  tov_200: number = 0
  tov_100: number = 0
  tov_50: number = 0
  tov_20: number = 0
  tov_10: number = 0

  tso_2000: number = 0
  tso_500: number = 0
  tso_200: number = 0
  tso_100: number = 0
  tso_50: number = 0
  tso_20: number = 0
  tso_10: number = 0

  tswo_2000: number = 0
  tswo_500: number = 0
  tswo_200: number = 0
  tswo_100: number = 0
  tswo_50: number = 0
  tswo_20: number = 0
  tswo_10: number = 0

  tswso_2000: number = 0
  tswso_500: number = 0
  tswso_200: number = 0
  tswso_100: number = 0
  tswso_50: number = 0
  tswso_20: number = 0
  tswso_10: number = 0

  switch1: boolean = false
  switch2: boolean = false
  switch3: boolean = false
  switch4: boolean = false
  switch5: boolean = false
  switch6: boolean = false
  switch7: boolean = false
  switch8: boolean = false
  switch9: boolean = false

  rating1: number = null
  rating2: number = null
  rating3: number = null
  rating4: number = null
  rating5: number = null
  rating6: number = null
  rating7: number = null
  rating8: number = null
  rating9: number = null

  total_score: number = null
  risk_score: string = null

  all_data: boolean = false
  all_pcav: boolean = false
  all_casc: boolean = false
  all_camc: boolean = false
  all_ostn: boolean = false
  all_disc: boolean = false
  all_osnil: boolean = false
  all_control_pt: boolean = false
  signature_img_custodian1: boolean= false
  signature_img_custodian2: boolean= false
  signature_img_auditor: boolean= false
  emp_id_list: any = []
  name_cust_list: any = []

  location_name: string
  location_name_header:string
  audit_done_by: string
  date_of_audit: string =null
  date_of_audit_ov: string =null
  date_of_audit_so: string =null
  atm_id: string
  bank_name: string
  time_of_audit: string
  name_cust1: string
  emp_id1: string
  name_cust2: string
  emp_id2: string

  comments: string = null

  location: string
  region: string=null
  zone: string
  type: string =null
  type_dis:string =null
  type_sort:string =null
  type_cbr:string =null
  route_name: string =null
  inc_mc : number=0
  amnto_b : number=0
  amnts_b : number=0

  sent_to_server: boolean = false
  error_sending: boolean = true

  save_info: any = null
  save_json: string = null

  date: Date = new Date()
  minDate: Date

  lat_stamp: number = 0
  long_stamp: number = 0

  image_upload_url: string

  confirm_pressed: boolean = false
  total_pso :number=0
  total_pov :number=0
  total_sov :number=0
  total_sso :number=0

  check_desc :string =null


  constructor(private router: Router, private http: HttpClient) {
    this.datepickerconfig =Object.assign({}, {
      containerClass: this.colorTheme 
      
    });

    this.minDate =new Date()
   }

  ngOnInit() {

    this.confirm_pressed = false
    

    this.server_json = require('./../../../config.json');
    this.server_name = this.server_json['server'];
    this.service_name = this.server_name.concat('/atm')
    this.service_name_type_audit = this.server_name.concat('/atm-audit-type')
    this.service_name_type_discrepency=this.server_name.concat('/atm-dicrepency-type')
    this.service_name_type_sortage=this.server_name.concat('/atm-sortage-type')
    this.service_name_loc = this.server_name.concat('/demographic')
    this.service_name_atm = this.server_name.concat('/atm-mapping')
    this.service_name_bank = this.server_name.concat('/bank-mapping')
    this.service_name_datetime = this.server_name.concat('/datetime')
    this.service_name_custodian = this.server_name.concat('/custodian')
    this.service_name_atm_master = this.server_name.concat('/atm-master')
    this.image_upload_url = this.server_name.concat('/images')


    this.login_token = localStorage.getItem('CMSAppUserLogin');
    if (this.login_token) {
      this.access = JSON.parse(this.login_token);
    }
    else {
      this.router.navigateByUrl('/', { skipLocationChange: false }).then(() =>
        this.router.navigate(["/login"]));
    }


    // this.location = this.access['location']
    // if (this.location) {
      this.atmMasterFetch()
    // }

    // this.type = this.access['type']
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Frame-Options': 'DENY'
      })
    };

    // this.region = this.region1
    // this.zone = this.zone1
    // this.route_name = this.route_name
   

    this.audit_done_by = this.access['emp_id'] + " " + this.access['name']
    if(this.access['type']=='auditor'){
      this.location_name_header =this.access['location']

    }
    
    
   
    

    if (this.server_name) {
      this.http.post(this.service_name_datetime, {}, httpOptions)
        .catch(error => {
          alert("Could not connect to the server. Retry after some time.")
          this.date_of_audit = ((this.date.getDate() < 10 ? '0' : '') + this.date.getDate()) + '-' + (((this.date.getMonth() + 1) < 10 ? '0' : '') + (this.date.getMonth() + 1)) + '-' + this.date.getFullYear();
          this.time_of_audit = ((this.date.getHours() < 10 ? '0' : '') + this.date.getHours()) + ':' + ((this.date.getMinutes() < 10 ? '0' : '') + this.date.getMinutes()) + ':' + ((this.date.getSeconds() < 10 ? '0' : '') + this.date.getSeconds())
          return EMPTY
        })
        .subscribe(data => {
          this.response_datetime = data
          this.date_of_audit = this.response_datetime['date_server']
          this.time_of_audit = this.response_datetime['time_server']
        });
    }


    this.save_json = localStorage.getItem('CMSAppUserSavedATM')
    this.save_info = JSON.parse(this.save_json)
    if (this.save_info) {
      [this.switch1, this.switch2, this.switch3, this.switch4, this.switch5, this.switch6, this.switch7, this.switch8, this.switch9, this.location_name, this.route_name,this.audit_done_by,this.date_of_audit,this.date_of_audit_ov,this.date_of_audit_so,this.time_of_audit,this.atm_id, this.bank_name, this.name_cust1, this.emp_id1, this.name_cust2, this.emp_id2, this.msp, this.comments, this.atm_cs_2000, this.atm_cs_500, this.atm_cs_200, this.atm_cs_100, this.atm_cs_50, this.atm_cs_20, this.atm_cs_10, this.atm_pb_2000, this.atm_pb_500, this.atm_pb_200, this.atm_pb_100, this.atm_pb_50, this.atm_pb_20, this.atm_pb_10, this.atm_oc_2000, this.atm_oc_500, this.atm_oc_200, this.atm_oc_100, this.atm_oc_50, this.atm_oc_20, this.atm_oc_10, this.sc_2000, this.sc_500, this.sc_200, this.sc_100, this.sc_50, this.sc_20, this.sc_10, this.mc_2000, this.mc_500, this.mc_200, this.mc_100, this.mc_50, this.mc_20, this.mc_10, this.tn_2000, this.tn_500, this.tn_200, this.tn_100, this.tn_50, this.tn_20, this.tn_10,this.type_dis,this.nil_2000, this.nil_500, this.nil_200, this.nil_100, this.nil_50, this.nil_20, this.nil_10, this.tov_2000, this.tov_500, this.tov_200, this.tov_100, this.tov_50, this.tov_20, this.tov_10, this.inc_mc, this.amnto_b, this.tso_2000, this.tso_500, this.tso_200, this.tso_100, this.tso_50, this.tso_20, this.tso_10,this.type, this.type_cbr, this.type_sort, this.amnts_b, this.tswo_2000, this.tswo_500, this.tswo_200, this.tswo_100, this.tswo_50, this.tswo_20,  this.tswo_10, this.tswso_2000,this.tswso_500,this.tswso_200,this.tswso_100,this.tswso_50,this.tswso_20,this.tswso_10,this.all_data, this.all_camc, this.all_casc, this.all_control_pt, this.all_ostn,this.all_osnil, this.all_pcav, this.zone1, this.region1,this.signatureImage_custodian1,this.signatureImage_custodian2,this.signatureImage_auditor]= this.save_info
    }

    // this.getDemographic()
    this.getCustodianData()
    
    


    WebcamUtil.getAvailableVideoInputs()
      .then((mediaDevices: MediaDeviceInfo[]) => {
        this.multipleWebcamsAvailable = mediaDevices && mediaDevices.length > 1;
      });

  }

  notify(data){
    
    console.log("inisde notify")
    if(this.route_name==null && data==1){
      alert('please enter the route name')
    }

    if(this.type==null && data==2){
      alert('please select  the type of audit ')
    }
    if(this.type_dis=='Reason for discrepency' && data==3){
      alert('please select the discrepency type')
    }
    if(this.type_dis=='Physical Shortage'||this.type_dis=='Physical-Overage/Shortage'){
      if(this.type_cbr ==null && data==4){
        this.check_desc =null
        alert('please select Reported In CBR')
        // this.notify(5)
      }
      if(this.type_dis =='Physical Shortage'||this.type_dis=='Physical-Overage/Shortage'){
        if(this.type_sort ==null && data==5) {
          this.check_desc =null
        alert('please select the  type of shortage')
        }
      }
    }
    this.check_desc ='Ok'
   

  }
 

  public triggerSnapshot(): void {
    this.trigger.next();
  }

  public toggleWebcam(): void {
    this.showWebcam = !this.showWebcam;
  }

  public handleInitError(error: WebcamInitError): void {
    this.errors.push(error);
  }

  public showNextWebcam(directionOrDeviceId: boolean | string): void {
    this.nextWebcam.next(directionOrDeviceId);
  }

  public handleImage(webcamImage: WebcamImage): void {
    this.webcamImage = webcamImage;
    if(this.webcamImageArr.length<4) {
      this.webcamImageArr.push(this.webcamImage);
    } 
    else {
      alert("Maximum 4 images are allowed.")
    }
  }

  public cameraWasSwitched(deviceId: string): void {
    this.deviceId = deviceId;
  }

  public get triggerObservable(): Observable<void> {
    return this.trigger.asObservable();
  }

  public get nextWebcamObservable(): Observable<boolean | string> {
    return this.nextWebcam.asObservable();
  }

  // showImage(data) {
  //   this.signature_img_custodian1_custodian1=true
  //   console.log("inside signature")
  //   this.signatureImage = data;
  //   console.log(data);
  // }
  showImage(type) {
    console.log(type)
    if(type==='c1') {
      this.signature_img_custodian1=true
      this.signatureImage_custodian1 = this.signaturePad.toDataURL('image/png,0.5');
      console.log("c1");
      console.log(this.signatureImage_custodian1);
    }
    if(type==='c2') {
      this.signature_img_custodian2=true
      this.signatureImage_custodian2 = this.signaturePad2.toDataURL('image/png,0.5');
      console.log("c2");
      console.log(this.signatureImage_custodian2);
    }
    if(type==='A') {
      this.signature_img_auditor=true
      this.signatureImage_auditor = this.signaturePad3.toDataURL('image/png,0.5');
      console.log("A");
      console.log(this.signatureImage_auditor);
    }
    console.log("inside signature")
  }
  resetSign(type){

    if(type==='c1') {
      console.log("inside reset")
      this.signature_img_custodian1=false
      this.signaturePad.clear();
    }
    if(type==='c2') {
      console.log("inside reset")
      this.signature_img_custodian2=false
      this.signaturePad2.clear();
    }
    if(type==='A') {
      console.log("inside reset")
      this.signature_img_auditor=false
    this.signaturePad3.clear();
    }
  }

  formatDate(date) {
    var dateParts = date.split('-')
    var d = new Date(+dateParts[2], dateParts[1] - 1, +dateParts[0]),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();

    if (month.length < 2)
      month = '0' + month;
    if (day.length < 2)
      day = '0' + day;

    return [year, month, day].join('');
  }

  uploadImages() {

    this.date_img = this.formatDate(this.date_of_audit)
    this.request_img = []

    if (this.webcamImageArr[0]) {

      this.image_names = "ATM/" + this.date_img.slice(0, 6) + "/" + this.atm_id.split(' ').join('_') + "_" + this.date_img + "_1.jpg"

      this.request_img.push({
        "Name": "ATM/" + this.date_img.slice(0, 6) + "/" + this.atm_id.split(' ').join('_') + "_" + this.date_img + "_1.jpg",
        "Image": this.webcamImageArr[0]['imageAsBase64'],
        "ImageType": "jpg"
      })
    }
    if (this.webcamImageArr[1]) {

      this.image_names += ",ATM/" + this.date_img.slice(0, 6) + "/" + this.atm_id.split(' ').join('_') + "_" + this.date_img + "_2.jpg"

      this.request_img.push({
        "Name": "ATM/" + this.date_img.slice(0, 6) + "/" + this.atm_id.split(' ').join('_') + "_" + this.date_img + "_2.jpg",
        "Image": this.webcamImageArr[1]['imageAsBase64'],
        "ImageType": "jpg"
      })
    }
    if (this.webcamImageArr[2]) {

      this.image_names += ",ATM/" + this.date_img.slice(0, 6) + "/" + this.atm_id.split(' ').join('_') + "_" + this.date_img + "_3.jpg"

      this.request_img.push({
        "Name": "ATM/" + this.date_img.slice(0, 6) + "/" + this.atm_id.split(' ').join('_') + "_" + this.date_img + "_3.jpg",
        "Image": this.webcamImageArr[2]['imageAsBase64'],
        "ImageType": "jpg"
      })
    }
    if (this.webcamImageArr[3]) {

      this.image_names +=",ATM/" + this.date_img.slice(0, 6) + "/" + this.atm_id.split(' ').join('_') + "_" + this.date_img + "_4.jpg"

      this.request_img.push({
        "Name": "ATM/" + this.date_img.slice(0, 6) + "/" + this.atm_id.split(' ').join('_') + "_" + this.date_img + "_4.jpg",
        "Image": this.webcamImageArr[3]['imageAsBase64'],
        "ImageType": "jpg"
      })
    }


    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Frame-Options': 'DENY'
      })
    };
    this.http.post(this.image_upload_url, this.request_img, httpOptions)
      .catch(error => {
        alert("Could not connect to the server. Retry after some time.")
        return EMPTY
      })
      .subscribe(data => {
        this.response_img = data
        if (this.response_img['IsSuccess']) {
          this.callFinalAPI()
        }
        else {
          alert("Could not upload images to the server. Please edit and retry.")
        }
      });

  }
  getAuditType(){
      const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Frame-Options': 'DENY'
      })
    };
    
      this.http.post(this.service_name_type_audit ,{},  httpOptions)
        .catch(error => {
          alert("Could not connect to the server. Retry after some time.")
          return EMPTY
        })
        .subscribe(data => {
          this.checklist_name=data['checklist_name']
         
        });

  }
  getDiscrepency(){

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Frame-Options': 'DENY'
      })
    };
    
      this.http.post(this.service_name_type_discrepency ,{"cash_flag":this.cash_flag},  httpOptions)
        .catch(error => {
          alert("Could not connect to the server. Retry after some time.")
          return EMPTY
        })
        .subscribe(data => {
          this.checklist_dis_name=data['checklist_name']
         
        });
      
       
        
  }

  getShortageType(){
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Frame-Options': 'DENY'
      })
    };
    
      this.http.post(this.service_name_type_sortage ,{},  httpOptions)
        .catch(error => {
          alert("Could not connect to the server. Retry after some time.")
          return EMPTY
        })
        .subscribe(data => {
          this.checklist_sort_name=data['checklist_name']
          
         
        });
        // this.notify(4)
  }

  getCbr(){
    this.cbr=['Yes','No']
  

  }
  calculatePhysicalOverageAndSortage(){   
    this.pc_2000 = this.atm_cs_2000+this.atm_oc_2000+this.atm_pb_2000
    this.pc_500 = this.atm_cs_500+this.atm_oc_500+this.atm_pb_500
    this.pc_200 = this.atm_cs_200+this.atm_oc_200+this.atm_pb_200
    this.pc_100 = this.atm_cs_100+this.atm_oc_100+this.atm_pb_100
    this.pc_50 = this.atm_cs_50+this.atm_oc_50+this.atm_pb_50
    this.pc_20 = this.atm_cs_20+this.atm_oc_20+this.atm_pb_20
    this.pc_10 = this.atm_cs_10+this.atm_oc_10+this.atm_pb_10

    if(this.mc_2000-this.pc_2000<0){
      this.tov_2000 =this.mc_2000-this.pc_2000
    }
    else if(this.mc_2000-this.pc_2000==0){
      this.tso_2000 =this.mc_2000-this.pc_2000
      this.tov_2000 =this.mc_2000-this.pc_2000
    }
    else{
      this.tso_2000 =this.mc_2000-this.pc_2000
    }
    if(this.mc_500-this.pc_500<0){
      this.tov_500 =this.mc_500-this.pc_500
    }
    else if(this.mc_500-this.pc_500==0){
      this.tso_500 =this.mc_500-this.pc_500
      this.tov_500 =this.mc_500-this.pc_500
    }
    else{
      this.tso_500 =this.mc_500-this.pc_500
    }
    if(this.mc_200-this.pc_200<0){
      this.tov_200 =this.mc_200-this.pc_200
    }
    else if(this.mc_200-this.pc_200==0){
      this.tso_200 =this.mc_200-this.pc_200
      this.tov_200 =this.mc_200-this.pc_200
    }
    else{
      this.tso_200 =this.mc_200-this.pc_200
    }
    if(this.mc_100-this.pc_100<0){
      this.tov_100 =this.mc_100-this.pc_100
    }
    else if(this.mc_100-this.pc_100==0){
      this.tso_100 =this.mc_100-this.pc_100
      this.tov_100 =this.mc_100-this.pc_100
    }
    else{
      this.tso_100 =this.mc_100-this.pc_100
    }
    if(this.mc_50-this.pc_50<0){
      this.tov_50 =this.mc_50-this.pc_50
    }
    else if(this.mc_50-this.pc_500==0){
      this.tso_50 =this.mc_50-this.pc_50
      this.tov_50 =this.mc_50-this.pc_50
    }
    else{
      this.tso_50 =this.mc_50-this.pc_50
    }
    if(this.mc_20-this.pc_20<0){
      this.tov_20 =this.mc_20-this.pc_20
    }
    else if(this.mc_20-this.pc_20==0){
      this.tso_20 =this.mc_20-this.pc_20
      this.tov_20 =this.mc_20-this.pc_20
    }
    else{
      this.tso_20 =this.mc_20-this.pc_20
    }
    if(this.mc_10-this.pc_10<0){
      this.tov_10 =this.mc_10-this.pc_10
    }
    else if(this.mc_10-this.pc_10==0){
      this.tso_10 =this.mc_10-this.pc_10
      this.tov_10 =this.mc_10-this.pc_10
    }
    else{
      this.tso_10 =this.mc_10-this.pc_10
    }

    this.total_pov =2000*this.tov_2000  + 500*this.tov_500 + 200*this.tov_200 + 100*this.tov_100 + 50*this.tov_50 + 20*this.tov_20 + 10*this.tov_10
    this.total_pso =2000*this.tso_2000  + 500*this.tso_500 + 200*this.tso_200 + 100*this.tso_100 + 50*this.tso_50 + 20*this.tso_20 + 10*this.tso_10
    if(this.total_pov==0&&this.total_pso==0){
      this.cash_flag ==true
    }
  
    this.calculateSwitchOverageAndSortage()
     
  }

  calculateSwitchOverageAndSortage(){
    if((this.mc_2000*2000)-this.sc_2000<0){
      this.tswo_2000 =(this.mc_2000*2000)-this.sc_2000
      
    }
    else if((this.mc_2000*2000)-this.sc_2000==0){
      this.tswo_2000 =(this.mc_2000*2000)-this.sc_2000
      this.tswso_2000 =(this.mc_2000*2000)-this.sc_2000
    }
    else{
      this.tswso_2000 =(this.mc_2000*2000)-this.sc_2000

    }
    if((this.mc_500*500)-this.sc_500<0){
      this.tswo_500 =(this.mc_500*500)-this.sc_500
    }
    else if((this.mc_500*500)-this.sc_500==0){
      this.tswo_500 =(this.mc_500*500)-this.sc_500
      this.tswso_500 =(this.mc_500*500)-this.sc_500
    }
    else{
      this.tswso_500 =(this.mc_500*500)-this.sc_500
    }
    if((this.mc_200*200)-this.sc_200<0){
      this.tswo_200 =(this.mc_200*200)-this.sc_200
    }
    else if((this.mc_200*200)-this.sc_200==0){
      this.tswo_200 =(this.mc_200*200)-this.sc_200
      this.tswso_200 =(this.mc_200*200)-this.sc_200
    }
    else{
      this.tswso_200 =(this.mc_200*200)-this.sc_200
    }
    if((this.mc_100*100)-this.sc_100<0){
      this.tswo_100 =(this.mc_100*100)-this.sc_100
    }
    else if((this.mc_100*100)-this.sc_100==0){
      this.tswo_100 =(this.mc_100*100)-this.sc_100
      this.tswso_100 =(this.mc_100*100)-this.sc_100
    }
    else{
      this.tswso_100 =(this.mc_100*100)-this.sc_100
    }
    if((this.mc_50*50)-this.sc_50<0){
      this.tswo_50 =(this.mc_50*50)-this.sc_50
    }
    else if((this.mc_50*50)-this.pc_500==0){
      this.tswo_50 =(this.mc_50*50)-this.sc_50
      this.tswso_50 =(this.mc_50*50)-this.sc_50
    }
    else{
      this.tswso_50 =(this.mc_50*50)-this.sc_50
    }
    if((this.mc_20*20)-this.sc_20<0){
      this.tswo_20 =(this.mc_20*20)-this.sc_20
    }
    else if((this.mc_20*20)-this.sc_20==0){
      this.tswo_20 =(this.mc_20*20)-this.sc_20
      this.tswso_20 =(this.mc_20*20)-this.sc_20
    }
    else{
      this.tswso_20 =(this.mc_20*20)-this.sc_20
    }
    if((this.mc_10*10)-this.sc_10<0){
      this.tswo_10 =(this.mc_10*10)-this.sc_10
    }
    else if((this.mc_10*10)-this.sc_10==0){
      this.tswo_10 =(this.mc_10*10)-this.sc_10
      this.tswso_10 =(this.mc_10*10)-this.sc_10
    }
    else{
      this.tswso_10 =(this.mc_10*10)-this.sc_10
    }

    this.total_sov =this.tswo_2000  + this.tswo_500 + this.tswo_200 + this.tswo_100 + this.tswo_50 + this.tswo_20 + this.tswo_10;
   
    this.total_sso =this.tswso_2000  + this.tswso_500 + this.tswso_200 + this.tswso_100 + this.tswso_50 +this.tswso_20 + this.tswso_10
  
    if(this.total_pov==0&&this.total_pso==0 && this.total_sov==0&& this.total_sso==0){
      this.cash_flag=true
    }
        
  }


  // calculateSwitchOverageAndSortage(){
    
  //   if((this.mc_2000-(this.sc_2000/200))<0){
  //     this.tswo_2000 =(this.mc_2000-(this.sc_2000/2000))
  //   }
  //   else if((this.mc_2000-(this.sc_2000/2000))==0){
  //     this.tswo_2000 =this.mc_2000-(this.sc_2000/2000)
  //     this.tswso_2000 =this.mc_2000-(this.sc_2000/2000)
  //   }
  //   else{
  //     this.tswso_2000 =(this.mc_2000-(this.sc_2000/2000))
  //   }
  //   if((this.mc_500-(this.sc_500/500))<0){
  //     this.tswo_500 =this.mc_500-(this.sc_500/500)
  //   }
  //   else if((this.mc_500-(this.sc_500/500))==0){
  //     this.tswo_500 =this.mc_500-(this.sc_500/500)
  //     this.tswso_500 =this.mc_500-(this.sc_500/500)
  //   }
  //   else{
  //     this.tswso_500 =(this.mc_500)-(this.sc_500/500)
  //   }
  //   if((this.mc_200)-(this.sc_200/200)<0){
  //     this.tswo_200 =(this.mc_200)-(this.sc_200/200)
  //   }
  //   else if((this.mc_200)-(this.sc_200/200)==0){
  //     this.tswo_200 =(this.mc_200)-(this.sc_200/200)
  //     this.tswso_200 =(this.mc_200)-(this.sc_200/200)
  //   }
  //   else{
  //     this.tswso_200 =(this.mc_200)-(this.sc_200/200)
  //   }
  //   if((this.mc_100)-(this.sc_100/100)<0){
  //     this.tswo_100 =(this.mc_100)-(this.sc_100/100)
  //   }
  //   else if((this.mc_100)-(this.sc_100/100)==0){
  //     this.tswo_100 =(this.mc_100)-(this.sc_100/100)
  //     this.tswso_100 =(this.mc_100)-(this.sc_100/100)
  //   }
  //   else{
  //     this.tswso_100 =(this.mc_100)-(this.sc_100/100)
  //   }
  //   if((this.mc_50)-(this.sc_50/50)<0){
  //     this.tswo_50 =(this.mc_50)-(this.sc_50/50)
  //   }
  //   else if((this.mc_50)-(this.sc_50/50)==0){
  //     this.tswo_50 =(this.mc_50)-(this.sc_50/50)
  //     this.tswso_50 =(this.mc_50)-(this.sc_50/50)
  //   }
  //   else{
  //     this.tswso_50 =(this.mc_50)-(this.sc_50/50)
  //   }
  //   if((this.mc_20)-(this.sc_20/20)<0){
  //     this.tswo_20 =(this.mc_20)-(this.sc_20/20)
  //   }
  //   else if((this.mc_20)-(this.sc_20/20)==0){
  //     this.tswo_20 =(this.mc_20)-(this.sc_20/20)
  //     this.tswso_20 =(this.mc_20)-(this.sc_20/20)
  //   }
  //   else{
  //     this.tswso_20 =(this.mc_20)-(this.sc_20/20)
  //   }
  //   if((this.mc_10)-(this.sc_10/10)<0){
  //     this.tswo_10 =(this.mc_10)-(this.sc_10/10)
  //   }
  //   else if((this.mc_10)-(this.sc_10/10)==0){
  //     this.tswo_10 =(this.mc_10)-(this.sc_10/10)
  //     this.tswso_10 =(this.mc_10)-(this.sc_10/10)
  //   }
  //   else{
  //     this.tswso_10 =(this.mc_10)-(this.sc_10/10)
  //   }

  //   this.total_sov =2000*this.tswo_2000  + 500*this.tswo_500 + 200*this.tswo_200 +100* this.tswo_100 + 50*this.tswo_50 +20* this.tswo_20 + 10*this.tswo_10;
  //   this.total_sso =2000*this.tswso_2000  + 500*this.tswso_500 + 200*this.tswso_200 +100* this.tswso_100 + 50*this.tswso_50 + 20*this.tswso_20 +10* this.tswso_10
  
  //   if(this.total_pov==0&&this.total_pso==0 && this.total_sov==0&& this.total_sso==0){
  //     this.cash_flag=true
  //   }
        
  // }


  getAtmMapping(){
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Frame-Options': 'DENY'
      })
    };

    this.http.post(this.service_name_atm, { 'atm_id': this.atm_id}, httpOptions)
      .catch(error => {
        alert("Could not connect to the server. Retry after some time.")
        return EMPTY
      })
      .subscribe(data => { 
        this.reponse2=data
        this.region1=this.reponse2.data.region
        this.location_name = this.reponse2.data.location
        if(this.access['type']!='auditor'){
        this.location_name_header =this.location_name
        }
        this.zone1 = this.reponse2.data.zone
       this.getMapBankping(); 
      });
   

  }

  getMapBankping(){
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Frame-Options': 'DENY'
      })
    };

    this.http.post(this.service_name_bank, { 'atm_id': this.atm_id}, httpOptions)
      .catch(error => {
        alert("Could not connect to the server. Retry after some time.")
        return EMPTY
      })
      .subscribe(data => {
        
        this.reponse3=data
        this.msp=this.reponse3.data.msp
        this.bank_name = this.reponse3.data.bank
       
        
      });
   

  }

  // getDemographic() {

  //   const httpOptions = {
  //     headers: new HttpHeaders({
  //       'Content-Type': 'application/json'
  //     })
  //   };

  //   this.http.post(this.service_name_loc, { 'username': this.access['username'], 'zone': this.access['zone'], 'region': this.access['region'] }, httpOptions)
  //     .catch(error => {
  //       alert("Could not connect to the server. Retry after some time.")
  //       return EMPTY
  //     })
  //     .subscribe(data => {
  //       this.regions = data['regions']
  //       this.locations = data['locations']
  //       this.zones = data['zones']
  //     });
  // }

  // checkLocation() {
  //   if (!this.access['location']) {
  //     alert('Please enter the location.')
  //   }
  // }

  resetButton() {
    this.scrollTop()
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() =>
      this.router.navigate(["/atm"]));
  }

  submitButton() {
    

    this.calculatePhysicalOverageAndSortage()
    this.calculateSwitchOverageAndSortage()
    this.getLocation()

    this.physicalCashTally()


    this.checkGeneralData()
    this.checkNotify()

    this.error_sending = false

    if (this.all_data && this.atleastoneinMachineCounter() && this.all_casc && this.all_control_pt && this.all_ostn && this.all_osnil && this.atleastoneinCasette() && this.webcamImageArr[0] && !this.errors[0])
     {
      this.incomplete = false
      this.review_mode = true
      this.saveLocal()
      this.calculateRatings()
      this.scrollTop()
    }
    else {
      this.incomplete = true
    }
  }

  saveLocal() {
    this.save_info = [this.switch1, this.switch2, this.switch3, this.switch4, this.switch5, this.switch6, this.switch7, this.switch8, this.switch9, this.location_name, this.route_name,this.audit_done_by,this.date_of_audit, this.date_of_audit_ov,this.date_of_audit_so, this.time_of_audit,this.atm_id, this.bank_name, this.name_cust1, this.emp_id1, this.name_cust2, this.emp_id2, this.msp, this.comments, this.atm_cs_2000, this.atm_cs_500, this.atm_cs_200, this.atm_cs_100, this.atm_cs_50, this.atm_cs_20, this.atm_cs_10, this.atm_pb_2000, this.atm_pb_500, this.atm_pb_200, this.atm_pb_100, this.atm_pb_50, this.atm_pb_20, this.atm_pb_10, this.atm_oc_2000, this.atm_oc_500, this.atm_oc_200, this.atm_oc_100, this.atm_oc_50, this.atm_oc_20, this.atm_oc_10, this.sc_2000, this.sc_500, this.sc_200, this.sc_100, this.sc_50, this.sc_20, this.sc_10, this.mc_2000, this.mc_500, this.mc_200, this.mc_100, this.mc_50, this.mc_20, this.mc_10, this.tn_2000, this.tn_500, this.tn_200, this.tn_100, this.tn_50, this.tn_20, this.tn_10,this.type_dis,this.nil_2000, this.nil_500, this.nil_200, this.nil_100, this.nil_50, this.nil_20, this.nil_10, this.tov_2000, this.tov_500, this.tov_200, this.tov_100, this.tov_50, this.tov_20, this.tov_10, this.inc_mc, this.amnto_b, this.tso_2000, this.tso_500, this.tso_200, this.tso_100, this.tso_50, this.tso_20, this.tso_10, this.type,this.type_cbr, this.type_sort, this.amnts_b, this.tswo_2000, this.tswo_500, this.tswo_200, this.tswo_100, this.tswo_50, this.tswo_20,  this.tswo_10, this.tswso_2000,this.tswso_500,this.tswso_200,this.tswso_100,this.tswso_50,this.tswso_20,this.tswso_10,this.all_data, this.all_camc, this.all_casc, this.all_control_pt, this.all_ostn,this.all_osnil, this.all_pcav, this.zone1, this.region1,this.signatureImage_custodian1,this.signatureImage_custodian2,this.signatureImage_auditor]
    localStorage.setItem('CMSAppUserSavedATM', JSON.stringify(this.save_info))
  }

  deleteLocal() {
    localStorage.removeItem('CMSAppUserSavedATM')
  }

  editButton() {
    this.scrollTop()
    this.review_mode = false
    this.confirm_pressed = false
  }

  confirmButton() {
    console.log("c1");
    console.log(this.signatureImage_custodian1);
    console.log("c2");
    console.log(this.signatureImage_custodian2);
    console.log("Auditor");
    console.log(this.signatureImage_auditor);
    this.confirm_pressed = true
    this.callFinalAPI()
   
  }

  callFinalAPI() {
    console.log("inside final request")
    this.request = {
      "checklist_type_id": 4,
      "username": this.access['username'],
      "total_score": this.total_score,
      "risk_score": this.risk_score,
      "location_name": this.location_name,
      "audit_done_by": this.audit_done_by,
      "signature_img_custodian1":this.signatureImage_custodian1,
      "signature_img_custodian2":this.signatureImage_custodian2,
      "signature_img_auditor":this.signatureImage_auditor, 
      "is_delete":0,
      "route_name":this.route_name,
      "type_audit":this.type,
      "date_of_audit": this.date_of_audit,
      "date_of_audit_ov": this.date_of_audit_ov,
      "date_of_audit_so": this.date_of_audit_so,
      "atm_id": this.atm_id,
      "bank_name": this.bank_name,
      "time_of_audit": this.time_of_audit,
      "name_cust1": this.name_cust1,
      "emp_id1": this.emp_id1,
      "name_cust2": this.name_cust2,
      "emp_id2": this.emp_id2,
      "msp": this.msp,
      "comments": this.comments,
      "f1c1_rs": this.switch1,
      "f1c1_rr": this.rating1,
      "f1c2_rs": this.switch2,
      "f1c2_rr": this.rating2,
      "f1c3_rs": this.switch3,
      "f1c3_rr": this.rating3,
      "f1c4_rs": this.switch4,
      "f1c4_rr": this.rating4,
      "f1c5_rs": this.switch5,
      "f1c5_rr": this.rating5,
      "f1c6_rs": this.switch6,
      "f1c6_rr": this.rating6,
      "f1c7_rs": this.switch7,
      "f1c7_rr": this.rating7,
      "f1c8_rs": this.switch8,
      "f1c8_rr": this.rating8,
      "f1c9_rs": this.switch9,
      "f1c9_rr": this.rating9,
      "atm_cs_2000": this.atm_cs_2000,
      "atm_cs_500": this.atm_cs_500,
      "atm_cs_200": this.atm_cs_200,
      "atm_cs_100": this.atm_cs_100,
      "atm_cs_50": this.atm_cs_50,
      "atm_cs_20": this.atm_cs_20,
      "atm_cs_10": this.atm_cs_10,
      "atm_pb_2000": this.atm_pb_2000,
      "atm_pb_500": this.atm_pb_500,
      "atm_pb_200": this.atm_pb_200,
      "atm_pb_100": this.atm_pb_100,
      "atm_pb_50": this.atm_pb_50,
      "atm_pb_20": this.atm_pb_20,
      "atm_pb_10": this.atm_pb_10,
      "atm_oc_2000": this.atm_oc_2000,
      "atm_oc_500": this.atm_oc_500,
      "atm_oc_200": this.atm_oc_200,
      "atm_oc_100": this.atm_oc_100,
      "atm_oc_50": this.atm_oc_50,
      "atm_oc_20": this.atm_oc_20,
      "atm_oc_10": this.atm_oc_10,
      "sc_2000": this.sc_2000,
      "sc_500": this.sc_500,
      "sc_200": this.sc_200,
      "sc_100": this.sc_100,
      "sc_50": this.sc_50,
      "sc_20": this.sc_20,
      "sc_10": this.sc_10,
      "mc_2000": this.mc_2000,
      "mc_500": this.mc_500,
      "mc_200": this.mc_200,
      "mc_100": this.mc_100,
      "mc_50": this.mc_50,
      "mc_20": this.mc_20,
      "mc_10": this.mc_10,
      "tn_2000": this.tn_2000,
      "tn_500": this.tn_500,
      "tn_200": this.tn_200,
      "tn_100": this.tn_100,
      "tn_50": this.tn_50,
      "tn_20": this.tn_20,
      "tn_10": this.tn_10,
      "nil_2000": this.nil_2000,
      "nil_500": this.nil_500,
      "nil_200": this.nil_200,
      "nil_100": this.nil_100,
      "nil_50": this.nil_50,
      "nil_20": this.nil_20,
      "nil_10": this.nil_10,
      "pov_2000":this.tov_2000,
      "pov_500":this.tov_500,
      "pov_200":this.tov_200,
      "pov_100":this.tov_100,
      "pov_50":this.tov_50,
      "pov_20":this.tov_20,
      "pov_10":this.tov_10,
      "pso_2000":this.tso_2000,
      "pso_500":this.tso_500,
      "pso_200":this.tso_200,
      "pso_100":this.tso_100,
      "pso_50":this.tso_50,
      "pso_20":this.tso_20,
      "pso_10":this.tso_10,
      "swo_2000":this.tswo_2000,
      "swo_500":this.tswo_500,
      "swo_200":this.tswo_200,
      "swo_100":this.tswo_100,
      "swo_50":this.tswo_50,
      "swo_20":this.tswo_20,
      "swo_10":this.tswo_10,
      "swso_2000":this.tswso_2000,
      "swso_500":this.tswso_500,
      "swso_200":this.tswso_200,
      "swso_100":this.tswso_100,
      "swso_50":this.tswso_50,
      "swso_20":this.tswso_20,
      "swso_10":this.tswso_10,
      "cbr":this.type_cbr,
      "inc_mc_swc":this.inc_mc,
      "discr_type":this.type_dis,
      "sort_type":this.type_sort,
      "amounto_bank":this.amnto_b,
      "amounts_bank":this.amnts_b,
      "chk_zone": this.zone1,
      "chk_region": this.region1,
      "chk_location": this.location_name,
      "lat_stamp": this.lat_stamp,
      "long_stamp": this.long_stamp,
      "images":this.image_names
    }


    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Frame-Options': 'DENY'
      })
    };

    if (this.server_name) {
      console.log("inside server")
      console.log(this.request)
      this.http.post(this.service_name, this.request, httpOptions)
        .catch(error => {
          alert("Could not connect to the server. Retry after some time.")
          return EMPTY
        })
        .subscribe(data => {
          this.response = data
          alert("Submitted checklist ID is"+this.response.checklist_id)
          this.serviceCalled()
        });
    }
  }

  serviceCalled() {

    if (this.response['status'] && this.response['status'] == "Success") {
      this.sent_to_server = true
    }
    else {
      this.sent_to_server = false
    }

    if (this.sent_to_server) {
      this.deleteLocal()
      setTimeout(() => {
        this.router.navigateByUrl('/', { skipLocationChange: false }).then(() =>
          this.router.navigate(["/history"]));
      },
        2000);
    }
    else {
      this.error_sending = true
    }
  }

  calculateRatings() {
    if (this.switch1) this.rating1 = 1
    else this.rating1 = 3
    if (this.switch2) this.rating2 = 1
    else this.rating2 = 3
    if (this.switch3) this.rating3 = 3
    else this.rating3 = 1
    if (this.switch4) this.rating4 = 3
    else this.rating4 = 1
    if (this.switch5) this.rating5 = 1
    else this.rating5 = 3
    if (this.switch6) this.rating6 = 1
    else this.rating6 = 3
    if (this.switch7) this.rating7 = 3
    else this.rating7 = 1
    if (this.switch8) this.rating8 = 1
    else this.rating8 = 3
    if (this.switch9) this.rating9 = 1
    else this.rating9 = 3
    this.total_score = this.rating1 + this.rating2 + this.rating3 + this.rating4 + this.rating5 + this.rating6 + this.rating7 + this.rating8 + this.rating9
    if (this.total_score >= 18) this.risk_score = "High"
    else if (this.total_score >= 12) this.risk_score = "Medium"
    else if (this.total_score >= 9) this.risk_score = "Low"
    else this.risk_score = "None"


  }

  checkGeneralData() {
  
    if (
      this.location_name && this.audit_done_by && this.date_of_audit && this.atm_id &&this.type  && this.bank_name && this.time_of_audit && this.name_cust1 && this.emp_id1 && this.name_cust2 && this.emp_id2 && this.msp && this.route_name ) {
      this.all_data = true
    }
    else {
      this.all_data = false
    }
  }

  checkNotify(){

    if(this.type_dis=='Physical Shortage'||this.type_dis=='Physical-Overage/Shortage'){
      if(this.type_cbr ==null ){
        alert('please select the Reported in Cbr from discrepency ')
        this.all_data =false
      }
    }
    if(this.type_dis =='Physical Shortage'||this.type_dis=='Physical-Overage/Shortage'){
        if(this.type_sort ==null) {
        alert('please select the  type of shortage from discrepency')
        this.all_data =false
        }

      }
  }

  scrollTop() {
    var pageTop = document.querySelector('#pagetop');
    pageTop.scrollIntoView();
  }


  wait(ms: number) {
    var start = new Date().getTime();
    var end = start;
    while (end < start + ms) {
      end = new Date().getTime();
    }
  }

  atmMasterFetch() {

   

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Frame-Options': 'DENY'
      })
    };
  
      this.http.post(this.service_name_atm_master, {  }, httpOptions)
        .catch(error => {
          alert("Could not connect to the server. Retry after some time.")
          return EMPTY
        })
        .subscribe(data => {
          this.response_atm_master = data
          if (this.response_atm_master['status'] && this.response_atm_master['status'] == "Success") {
            this.atm_id_list = this.response_atm_master['atm_id']
            this.msp_list = this.response_atm_master['msp']
            this.bank_list = this.response_atm_master['bank']
          }
          else {
            alert('No ATM data found for given location.')
          }
        });
  }

  getCustodianData() {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Frame-Options': 'DENY'
      })
    };
    this.http.post(this.service_name_custodian, {}, httpOptions)
      .catch(error => {
        alert("Could not connect to the server. Retry after some time.")
        return EMPTY
      })
      .subscribe(data => {
        this.response_custodian = data
        if (this.response_custodian['status'] && this.response_custodian['status'] == "Success") {
          this.emp_id_list = this.response_custodian['emp_id']
          this.name_cust_list = this.response_custodian['name_cust']
        }
        else {
          alert('Could not fetch Custodian list from the server.')
        }
      });
  }

  checkIfStarted() {
    if ((this.all_data || this.all_camc || this.all_casc || this.all_control_pt || this.all_ostn ||this.all_osnil|| this.all_pcav) && !this.sent_to_server) {
      return true
    }
    else {
      return false
    }
  }

  atleastoneinCasette() {
    if ((this.atm_cs_2000 || this.atm_cs_500 || this.atm_cs_200 || this.atm_cs_100) && this.all_pcav) {
      return true
    }
    else {
      return false
    }
  }

  atleastoneinMachineCounter() {
    if ((this.mc_2000 || this.mc_500 || this.mc_200 || this.mc_100) && this.all_camc) {
      return true
    }
    else {
      return false
    }
  }

  physicalCashTally() {
    this.os_2000 = this.atm_cs_2000 + this.atm_pb_2000 + this.atm_oc_2000 - this.mc_2000
    this.os_500 = this.atm_cs_500 + this.atm_pb_500 + this.atm_oc_500 - this.mc_500
    this.os_200 = this.atm_cs_200 + this.atm_pb_200 + this.atm_oc_200 - this.mc_200
    this.os_100 = this.atm_cs_100 + this.atm_pb_100 + this.atm_oc_100 - this.mc_100
    this.os_50 = this.atm_cs_50 + this.atm_pb_50 + this.atm_oc_50 - this.mc_50
    this.os_20 = this.atm_cs_20 + this.atm_pb_20 + this.atm_oc_20 - this.mc_20
    this.os_10 = this.atm_cs_10 + this.atm_pb_10 + this.atm_oc_10 - this.mc_10

    if ((this.os_2000 || this.os_500 || this.os_200 || this.os_100 || this.os_50 || this.os_20 || this.os_10)) {
      this.switch9 = false
    }
    else {
      this.switch9 = true
    }
  }

  getLocation() {
    navigator.geolocation.getCurrentPosition((pos) => this.setPosition(pos))
  }

  setPosition(position) {
    this.lat_stamp = position.coords.latitude;
    this.long_stamp = position.coords.longitude;
  }


}
