import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';


declare const $: any;
declare interface RouteInfo {
  path: string;
  title: string;
  icon: string;
  class: string;
}

export const ROUTES: RouteInfo[] = [
  { path: '/home', title: 'Home', icon: 'pe-7s-home', class: '' },
  { path: '/branch', title: 'Branch Audit', icon: 'pe-7s-culture', class: '' },
  { path: '/route', title: 'Route Audit', icon: 'pe-7s-car', class: '' },
  { path: '/vault', title: 'Vault Audit', icon: 'pe-7s-safe', class: '' },
  { path: '/atm', title: 'ATM Audit', icon: 'pe-7s-cash', class: '' },
  { path: '/history', title: 'History', icon: 'pe-7s-timer', class: '' },
  { path: '/reports', title: 'Reports', icon: 'pe-7s-news-paper', class: '' },
  // { path: '/login', title: 'Logout',  icon:'pe-7s-back-2', class: '' },

  // { path: '/upgrade', title: 'Upgrade to PRO',  icon:'pe-7s-rocket', class: 'active-pro' },
];

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html'
})
export class SidebarComponent implements OnInit {

  menuItems: any[];

  login_token: any
  access: any
  toggleButton: any

  constructor(private router: Router) { }

  ngOnInit() {

    this.login_token = localStorage.getItem('CMSAppUserLogin');
    if (this.login_token) {
      this.access = JSON.parse(this.login_token);
      this.access['home'] = true
      this.access['history'] = true;
    }

    this.menuItems = ROUTES.filter(menuItem => menuItem);

  }

  showItem(menuItem: any) {

    var link_item = menuItem.path.substr(1)

    if (this.access[link_item]) {
      return true
    }
    else {
      return false
    }
  }

  isMobileMenu() {
    if ($(window).width() > 991) {
      return false;
    }
    return true;
  };


  sidebarClose() {
    this.toggleButton = document.getElementsByClassName('navbar-toggle')[0];
    const body = document.getElementsByTagName('body')[0];
    this.toggleButton.classList.remove('toggled');
    body.classList.remove('nav-open');
  };

}
