import { Component, OnInit, ViewChild } from '@angular/core';
import { NgModule } from '@angular/core';

import { Router } from '@angular/router';

import { retry } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/add/operator/catch';
import { EMPTY } from 'rxjs';

import { Injectable } from '@angular/core';
import { CanDeactivate } from '@angular/router';


import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { WebcamImage, WebcamInitError, WebcamUtil } from 'ngx-webcam';
import { SignaturePad } from 'angular2-signaturepad/signature-pad';



@Injectable()
export class ConfirmDeactivateGuard1 implements CanDeactivate<UserComponent> {

  canDeactivate(target: UserComponent) {
    if (target.checkIfStarted()) {
      return window.confirm('Are you sure?');
    }
    return true;
  }

}
@NgModule({
  providers: [
    ConfirmDeactivateGuard1
  ]
})


@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  @ViewChild('signpad1') signaturePad: SignaturePad;
  @ViewChild('signpad2') signaturePad2: SignaturePad;

 
  private signaturePadOptions:  object= { // passed through to szimek/signature_pad constructor
    'minWidth': .5,
    penColor:'rgb(7, 8, 7)',
    backgroundColor:'rgb(255,255,255)',
    'canvasWidth': 400,
    'canvasHeight': 100
    
  };



  public showWebcam = true;
  public allowCameraSwitch = true;
  public multipleWebcamsAvailable = false;
  public deviceId: string;
  public videoOptions: MediaTrackConstraints = {
    // width: {ideal: 1024},
    // height: {ideal: 576}
  };
  public errors: WebcamInitError[] = [];

  // latest snapshot
  public webcamImage: WebcamImage = null;
  public webcamImageArr: any = []

  // webcam snapshot trigger
  private trigger: Subject<void> = new Subject<void>();
  // switch to next / previous / specific webcam; true/false: forward/backwards, string: deviceId
  private nextWebcam: Subject<boolean | string> = new Subject<boolean | string>();

  signature_img_custodian1: boolean= false
  signature_img_custodian2: boolean= false
  type_auditor:boolean=false

  signatureImage_custodian1: any= null;
  signatureImage_custodian2: any= null;
  request_img: any = []
  response_img: any = null
  emp_id_list: any = []
  name_cust_list: any = []
  emp_id_bm :any
  emp_id_zm :any



  image_names: string = null
  signature_img: boolean= false
  signatureImage: any= null;
  date_img: any = null
  sign_head_sup:string = null;


  server_json: any
  server_name: string
  service_name: string
  service_name_datetime: any
  service_name_user_master: any
  response_datetime: any
  response_user_master:any

  request: any
  response: any

  service_name_loc: string
  regions: any
  locations: any
  zones: any

  login_token: any
  access: any

  review_mode: boolean = false
  incomplete: boolean = false

  switch1: boolean = false
  switch2: boolean = false
  switch3: boolean = false
  switch4: boolean = false
  switch5: boolean = false
  switch6: boolean = false
  switch7: boolean = false
  switch8: boolean = false
  switch9: boolean = false
  switch10: boolean = false
  switch11: boolean = false
  switch12: boolean = false
  switch13: boolean = false
  switch14: boolean = false
  switch15: boolean = false
  switch16: boolean = false
  switch17: boolean = false
  switch18: boolean = false
  switch19: boolean = false
  switch20: boolean = false
  switch21: boolean = false
  switch22: boolean = false
  switch23: boolean = false
  switch24: boolean = false
  switch25: boolean = false
  switch26: boolean = false
  switch27: boolean = false
  switch28: boolean = false

  rating1: number = null
  rating2: number = null
  rating3: number = null
  rating4: number = null
  rating5: number = null
  rating6: number = null
  rating7: number = null
  rating8: number = null
  rating9: number = null
  rating10: number = null
  rating11: number = null
  rating12: number = null
  rating13: number = null
  rating14: number = null
  rating15: number = null
  rating16: number = null
  rating17: number = null
  rating18: number = null
  rating19: number = null
  rating20: number = null
  rating21: number = null
  rating22: number = null
  rating23: number = null
  rating24: number = null
  rating25: number = null
  rating26: number = null
  rating27: number = null
  rating28: number = null

  total_score: number = null
  risk_score: string = null

  all_security: boolean = false
  all_operations: boolean = false
  all_fleet: boolean = false
  all_hr: boolean = false
  all_accounts: boolean = false
  all_admin: boolean = false
  all_data: boolean = false

  branch_name: string
  audit_done_by: string
  date_of_audit: string
  region: string
  zone: string
  branch_manager: string
  regional_manager: string
  zonal_manager: string
  comments: string = null

  location_user: string
  region_user: string
  zone_user: string

  sent_to_server: boolean = false
  error_sending: boolean = true

  save_info: any = null
  save_json: string = null

  date: Date = new Date()

  lat_stamp: number = 0
  long_stamp: number = 0

  image_upload_url: string
  confirm_pressed: boolean = false

  constructor(private router: Router, private http: HttpClient) { }

  ngOnInit() {

    this.confirm_pressed = false

    this.server_json = require('./../../../config.json');
    this.server_name = this.server_json['server'];
    this.service_name = this.server_name.concat('/branch')
    this.service_name_user_master = this.server_name.concat('/custodian')
    this.service_name_loc = this.server_name.concat('/demographic')
    this.service_name_datetime = this.server_name.concat('/datetime')
    this.image_upload_url = this.server_name.concat('/images')


    this.login_token = localStorage.getItem('CMSAppUserLogin');
    if (this.login_token) {
      this.access = JSON.parse(this.login_token);
    }
    else {
      this.router.navigateByUrl('/', { skipLocationChange: false }).then(() =>
        this.router.navigate(["/login"]));
    }

    this.region_user = this.access['region']
    this.zone_user = this.access['zone']
    this.location_user = this.access['location']

    this.audit_done_by = this.access['emp_id'] + " " + this.access['name']
    this.branch_name = this.access['location']
    if(this.access['type']=='auditor'){
      this.type_auditor =true
      this.sign_head_sup = 'Branch Manager /Auditor Signature -Capture'
    }
    else {
      this.sign_head_sup = 'Branch Manager -Signature -Capture'
    }

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Frame-Options': 'DENY'
      })
    };

    if (this.server_name) {
      this.http.post(this.service_name_datetime, {}, httpOptions)
        .catch(error => {
          alert("Could not connect to the server. Retry after some time.")
          this.date_of_audit = ((this.date.getDate() < 10 ? '0' : '') + this.date.getDate()) + '-' + (((this.date.getMonth() + 1) < 10 ? '0' : '') + (this.date.getMonth() + 1)) + '-' + this.date.getFullYear();

          return EMPTY
        })
        .subscribe(data => {
          this.response_datetime = data
          this.date_of_audit = this.response_datetime['date_server']
        });
    }

    this.save_json = localStorage.getItem('CMSAppUserSavedBranch')
    this.save_info = JSON.parse(this.save_json)
    if (this.save_info) {
      [this.switch1, this.switch2, this.switch3, this.switch4, this.switch5, this.switch6, this.switch7, this.switch8, this.switch9, this.switch10, this.switch11, this.switch12, this.switch13, this.switch14, this.switch15, this.switch16, this.switch17, this.switch18, this.switch19, this.switch20, this.switch21, this.switch22, this.switch23, this.switch24, this.switch25, this.switch26, this.switch27, this.switch28, this.branch_name, this.audit_done_by, this.date_of_audit, this.region, this.zone, this.branch_manager, this.regional_manager, this.zonal_manager, this.comments, this.all_security, this.all_operations, this.all_fleet, this.all_hr, this.all_accounts, this.all_admin, this.all_data,this.signatureImage_custodian1,this.signatureImage_custodian2, this.access['zone'], this.access['region'], this.access['location']] = this.save_info
    }

    this.getDemographic()
    this.getUserMaster()



    WebcamUtil.getAvailableVideoInputs()
      .then((mediaDevices: MediaDeviceInfo[]) => {
        this.multipleWebcamsAvailable = mediaDevices && mediaDevices.length > 1;
      });

  }

  public triggerSnapshot(): void {
    this.trigger.next();
  }

  public toggleWebcam(): void {
    this.showWebcam = !this.showWebcam;
  }

  public handleInitError(error: WebcamInitError): void {
    this.errors.push(error);
  }

  public showNextWebcam(directionOrDeviceId: boolean | string): void {
    this.nextWebcam.next(directionOrDeviceId);
  }

  public handleImage(webcamImage: WebcamImage): void {
    this.webcamImage = webcamImage;
    if (this.webcamImageArr.length < 4) {
      this.webcamImageArr.push(this.webcamImage);
    }
    else {
      alert("Maximum 4 images are allowed.")
    }
  }

  public cameraWasSwitched(deviceId: string): void {
    this.deviceId = deviceId;
  }

  public get triggerObservable(): Observable<void> {
    return this.trigger.asObservable();
  }

  public get nextWebcamObservable(): Observable<boolean | string> {
    return this.nextWebcam.asObservable();
  }

  formatDate(date) {
    var dateParts = date.split('-')
    var d = new Date(+dateParts[2], dateParts[1] - 1, +dateParts[0]),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();

    if (month.length < 2)
      month = '0' + month;
    if (day.length < 2)
      day = '0' + day;

    return [year, month, day].join('');
  }

  uploadImages() {

    this.date_img = this.formatDate(this.date_of_audit)
    this.request_img = []

    if (this.webcamImageArr[0]) {

      this.image_names = "Branch/" + this.date_img.slice(0, 6) + "/" + this.branch_name.split(' ').join('_') + "_" + this.date_img + "_1.jpg"

      this.request_img.push({
        "Name": "Branch/" + this.date_img.slice(0, 6) + "/" + this.branch_name.split(' ').join('_') + "_" + this.date_img + "_1.jpg",
        "Image": this.webcamImageArr[0]['imageAsBase64'],
        "ImageType": "jpg"
      })
    }
    if (this.webcamImageArr[1]) {

      this.image_names += ",Branch/" + this.date_img.slice(0, 6) + "/" + this.branch_name.split(' ').join('_') + "_" + this.date_img + "_2.jpg"

      this.request_img.push({
        "Name": "Branch/" + this.date_img.slice(0, 6) + "/" + this.branch_name.split(' ').join('_') + "_" + this.date_img + "_2.jpg",
        "Image": this.webcamImageArr[1]['imageAsBase64'],
        "ImageType": "jpg"
      })
    }
    if (this.webcamImageArr[2]) {

      this.image_names += ",Branch/" + this.date_img.slice(0, 6) + "/" + this.branch_name.split(' ').join('_') + "_" + this.date_img + "_3.jpg"

      this.request_img.push({
        "Name": "Branch/" + this.date_img.slice(0, 6) + "/" + this.branch_name.split(' ').join('_') + "_" + this.date_img + "_3.jpg",
        "Image": this.webcamImageArr[2]['imageAsBase64'],
        "ImageType": "jpg"
      })
    }
    if (this.webcamImageArr[3]) {

      this.image_names += ",Branch/" + this.date_img.slice(0, 6) + "/" + this.branch_name.split(' ').join('_') + "_" + this.date_img + "_4.jpg"

      this.request_img.push({
        "Name": "Branch/" + this.date_img.slice(0, 6) + "/" + this.branch_name.split(' ').join('_') + "_" + this.date_img + "_4.jpg",
        "Image": this.webcamImageArr[3]['imageAsBase64'],
        "ImageType": "jpg"
      })
    }


    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Frame-Options': 'DENY'
      })
    };
    this.http.post(this.image_upload_url, this.request_img, httpOptions)
      .catch(error => {
        alert("Could not connect to the server. Retry after some time.")
        return EMPTY
      })
      .subscribe(data => {
        this.response_img = data
        if (this.response_img['IsSuccess']) {
          this.callFinalAPI()
        }
        else {
          alert("Could not upload images to the server. Please edit and retry.")
        }
      });

  }


  getUserMaster() {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Frame-Options': 'DENY'
      })
    };
    this.http.post(this.service_name_user_master, {}, httpOptions)
      .catch(error => {
        alert("Could not connect to the server. Retry after some time.")
        return EMPTY
      })
      .subscribe(data => {
        this.response_user_master = data
        if (this.response_user_master['status'] && this.response_user_master['status'] == "Success") {
          this.emp_id_list = this.response_user_master['emp_id']
          this.name_cust_list = this.response_user_master['name_cust']
        }
        else {
          alert('Could not fetch Custodian list from the server.')
        }
      });
  }

  getDemographic() {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Frame-Options': 'DENY'
      })
    };

    this.http.post(this.service_name_loc, { 'username': this.access['username'], 'zone': this.access['zone'], 'region': this.access['region'] }, httpOptions)
      .catch(error => {
        alert("Could not connect to the server. Retry after some time.")
        return EMPTY
      })
      .subscribe(data => {
        this.regions = data['regions']
        this.locations = data['locations']
        this.zones = data['zones']
      });
  }
 
  showImage(type) {
    if(type==='c1') {
      this.signature_img_custodian1=true
      this.signatureImage_custodian1 = this.signaturePad.toDataURL('image/png,0.5');
      console.log("c1");
      console.log(this.signatureImage_custodian1);
    }
    if(type==='c2') {
      this.signature_img_custodian2=true
      this.signatureImage_custodian2 = this.signaturePad2.toDataURL('image/png,0.5');
      console.log("c2");
      console.log(this.signatureImage_custodian2);
    }
  }
  resetSign(type){
    if(type==='c1') {
      console.log("inside reset")
      this.signature_img_custodian1=false
      this.signaturePad.clear();
    }
    if(type==='c2') {
      console.log("inside reset")
      this.signature_img_custodian2=false
      this.signaturePad2.clear();
    }
  }


  resetButton() {
    this.scrollTop()
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() =>
      this.router.navigate(["/branch"]));
  }

  submitButton() {

    this.zone = this.access['zone']
    this.region = this.access['region']

    this.getLocation()

    this.checkGeneralData()

    this.error_sending = false

    if (this.all_security && this.all_operations && this.all_fleet && this.all_hr && this.all_accounts && this.all_admin && this.all_data) {

      this.incomplete = false
      this.review_mode = true

      this.saveLocal()
      this.calculateRatings()
      this.scrollTop()
    }
    else {
      this.incomplete = true
    }
  }

  saveLocal() {
    this.save_info = [this.switch1, this.switch2, this.switch3, this.switch4, this.switch5, this.switch6, this.switch7, this.switch8, this.switch9, this.switch10, this.switch11, this.switch12, this.switch13, this.switch14, this.switch15, this.switch16, this.switch17, this.switch18, this.switch19, this.switch20, this.switch21, this.switch22, this.switch23, this.switch24, this.switch25, this.switch26, this.switch27, this.switch28, this.branch_name, this.audit_done_by, this.date_of_audit, this.region, this.zone, this.branch_manager, this.regional_manager, this.zonal_manager, this.comments, this.all_security, this.all_operations, this.all_fleet, this.all_hr, this.all_accounts, this.all_admin, this.all_data,this.signatureImage_custodian1,this.signatureImage_custodian2,this.access['zone'], this.access['region'], this.access['location']]
    localStorage.setItem('CMSAppUserSavedBranch', JSON.stringify(this.save_info))
  }

  deleteLocal() {
    localStorage.removeItem('CMSAppUserSavedBranch')
  }

  editButton() {
    this.scrollTop()
    this.review_mode = false
    this.confirm_pressed = false
  }

  confirmButton() {

    this.confirm_pressed = true

    if (!this.webcamImageArr[0]) {
      this.callFinalAPI()
    }
    else {
      this.uploadImages()
    }
  }

  callFinalAPI() {
    this.request = {
      "checklist_type_id": 1,
      "username": this.access['username'],
      "total_score": this.total_score,
      "risk_score": this.risk_score,
      "signature_img_custodian1":this.signatureImage_custodian1,
      "signature_img_custodian2":this.signatureImage_custodian2,
      "is_delete":0,
      "branch_name": this.branch_name,
      "audit_done_by": this.audit_done_by,
      "date_of_audit": this.date_of_audit,
      "region": this.region,
      "zone": this.zone,
      "branch_manager": this.branch_manager,
      "regional_manager": this.regional_manager,
      "zonal_manager": this.zonal_manager,
      "comments": this.comments,
      "f2c1_rs": this.switch1,
      "f2c1_rr": this.rating1,
      "f2c2_rs": this.switch2,
      "f2c2_rr": this.rating2,
      "f2c3_rs": this.switch3,
      "f2c3_rr": this.rating3,
      "f2c4_rs": this.switch4,
      "f2c4_rr": this.rating4,
      "f2c5_rs": this.switch5,
      "f2c5_rr": this.rating5,
      "f2c6_rs": this.switch6,
      "f2c6_rr": this.rating6,
      "f3c1_rs": this.switch7,
      "f3c1_rr": this.rating7,
      "f3c2_rs": this.switch8,
      "f3c2_rr": this.rating8,
      "f3c3_rs": this.switch9,
      "f3c3_rr": this.rating9,
      "f3c4_rs": this.switch10,
      "f3c4_rr": this.rating10,
      "f3c5_rs": this.switch11,
      "f3c5_rr": this.rating11,
      "f3c6_rs": this.switch12,
      "f3c6_rr": this.rating12,
      "f3c7_rs": this.switch13,
      "f3c7_rr": this.rating13,
      "f3c8_rs": this.switch14,
      "f3c8_rr": this.rating14,
      "f3c9_rs": this.switch15,
      "f3c9_rr": this.rating15,
      "f3c10_rs": this.switch16,
      "f3c10_rr": this.rating16,
      "f3c11_rs": this.switch17,
      "f3c11_rr": this.rating17,
      "f3c12_rs": this.switch18,
      "f3c12_rr": this.rating18,
      "f3c13_rs": this.switch19,
      "f3c13_rr": this.rating19,
      "f3c14_rs": this.switch20,
      "f3c14_rr": this.rating20,
      "f3c15_rs": this.switch21,
      "f3c15_rr": this.rating21,
      "f4c1_rs": this.switch22,
      "f4c1_rr": this.rating22,
      "f5c1_rs": this.switch23,
      "f5c1_rr": this.rating23,
      "f5c2_rs": this.switch24,
      "f5c2_rr": this.rating24,
      "f6c1_rs": this.switch25,
      "f6c1_rr": this.rating25,
      "f6c2_rs": this.switch26,
      "f6c2_rr": this.rating26,
      "f7c1_rs": this.switch27,
      "f7c1_rr": this.rating27,
      "f7c2_rs": this.switch28,
      "f7c2_rr": this.rating28,
      "chk_zone": this.access['zone'],
      "chk_region": this.access['region'],
      "chk_location": this.access['location'],
      "lat_stamp": this.lat_stamp,
      "long_stamp": this.long_stamp,
      "images": this.image_names
    }

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Frame-Options': 'DENY'
      })
    };

    if (this.server_name) {

      this.http.post(this.service_name, this.request, httpOptions)
        .catch(error => {
          alert("Could not connect to the server. Retry after some time.")
          return EMPTY
        })
        .subscribe(data => {
          this.response = data
          alert("Submitted checklist ID is"+this.response.checklist_id)
          this.serviceCalled()
        });
    }

  }

  serviceCalled() {

    if (this.response['status'] && this.response['status'] == "Success") {
      this.sent_to_server = true
    }
    else {

      this.sent_to_server = false
    }

    if (this.sent_to_server) {
      this.deleteLocal()
      setTimeout(() => {
        this.router.navigateByUrl('/', { skipLocationChange: false }).then(() =>
          this.router.navigate(["/history"]));
      },
        2000);
    }
    else {
      this.error_sending = true
    }
  }

  calculateRatings() {
    if (this.switch1) this.rating1 = 1
    else this.rating1 = 3
    if (this.switch2) this.rating2 = 1
    else this.rating2 = 3
    if (this.switch3) this.rating3 = 1
    else this.rating3 = 2
    if (this.switch4) this.rating4 = 1
    else this.rating4 = 3
    if (this.switch5) this.rating5 = 1
    else this.rating5 = 3
    if (this.switch6) this.rating6 = 1
    else this.rating6 = 3
    if (this.switch7) this.rating7 = 1
    else this.rating7 = 3
    if (this.switch8) this.rating8 = 1
    else this.rating8 = 3
    if (this.switch9) this.rating9 = 1
    else this.rating9 = 3
    if (this.switch10) this.rating10 = 1
    else this.rating10 = 3
    if (this.switch11) this.rating11 = 1
    else this.rating11 = 3
    if (this.switch12) this.rating12 = 1
    else this.rating12 = 3
    if (this.switch13) this.rating13 = 1
    else this.rating13 = 3
    if (this.switch14) this.rating14 = 1
    else this.rating14 = 3
    if (this.switch15) this.rating15 = 1
    else this.rating15 = 3
    if (this.switch16) this.rating16 = 1
    else this.rating16 = 3
    if (this.switch17) this.rating17 = 1
    else this.rating17 = 3
    if (this.switch18) this.rating18 = 1
    else this.rating18 = 3
    if (this.switch19) this.rating19 = 1
    else this.rating19 = 3
    if (this.switch20) this.rating20 = 1
    else this.rating20 = 3
    if (this.switch21) this.rating21 = 1
    else this.rating21 = 3
    if (this.switch22) this.rating22 = 1
    else this.rating22 = 2
    if (this.switch23) this.rating23 = 1
    else this.rating23 = 3
    if (this.switch24) this.rating24 = 1
    else this.rating24 = 3
    if (this.switch25) this.rating25 = 1
    else this.rating25 = 2
    if (this.switch26) this.rating26 = 1
    else this.rating26 = 3
    if (this.switch27) this.rating27 = 1
    else this.rating27 = 3
    if (this.switch28) this.rating28 = 1
    else this.rating28 = 2

    this.total_score = this.rating1 + this.rating2 + this.rating3 + this.rating4 + this.rating5 + this.rating6 + this.rating7 + this.rating8 + this.rating9 + this.rating10 + this.rating11 + this.rating12 + this.rating13 + this.rating14 + this.rating15 + this.rating16 + this.rating17 + this.rating18 + this.rating19 + this.rating20 + this.rating21 + this.rating22 + this.rating23 + this.rating24 + this.rating25 + this.rating26 + this.rating27 + this.rating28
    if (this.total_score >= 65) this.risk_score = "High"
    else if (this.total_score >= 50) this.risk_score = "Medium"
    else if (this.total_score >= 28) this.risk_score = "Low"
    else this.risk_score = "None"

  }

  checkGeneralData() {

    if (this.branch_name && this.audit_done_by && this.date_of_audit && this.branch_manager && this.regional_manager  && this.access['location'] && this.access['region'] && this.access['zone']) {
      if(this.zonal_manager==null){
        this.zonal_manager ='unassigned'
      }
      this.all_data = true
    }
    else {
      this.all_data = false
    }
  }

  scrollTop() {
    var pageTop = document.querySelector('#pagetop');
    pageTop.scrollIntoView();
  }


  wait(ms: number) {
    var start = new Date().getTime();
    var end = start;
    while (end < start + ms) {
      end = new Date().getTime();
    }
  }

  checkIfStarted() {
    if ((this.all_security || this.all_operations || this.all_fleet || this.all_hr || this.all_accounts || this.all_admin || this.all_data) && !this.sent_to_server) {
      return true
    }
    else {
      return false
    }
  }

  getLocation() {
    navigator.geolocation.getCurrentPosition((pos) => this.setPosition(pos))
  }

  setPosition(position) {
    this.lat_stamp = position.coords.latitude;
    this.long_stamp = position.coords.longitude;
  }

}
