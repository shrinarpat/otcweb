import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { retry } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/add/operator/catch';
import { EMPTY } from 'rxjs';

import {ViewEncapsulation} from '@angular/core';

declare const $: any;

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class HomeComponent implements OnInit {

  server_json: any
  server_name: string
  service_name: string
  service_name1:string

  request: any
  response: any

  request1: any
  response1: any

  login_token: any
  access: any

  got_history: boolean = false

  got_report: boolean = false

  constructor(private router: Router, private http: HttpClient) { }

  ngOnInit() {

    this.server_json = require('./../../../config.json');
    this.server_name = this.server_json['server'];
    this.service_name = this.server_name.concat('/home')
    this.service_name1 =this.server_name.concat('/supervisor-home')



    this.login_token = localStorage.getItem('CMSAppUserLogin');
    console.log(this.login_token);
    
    if (this.login_token) {
      this.access = JSON.parse(this.login_token);
      this.access['history'] = true
    }
    else {
      this.router.navigateByUrl('/', { skipLocationChange: false }).then(() =>
        this.router.navigate(["/login"]));
    }

    if (this.access['type'] == "auditor") {
      this.request = { "username": this.access['username'] }
    }
    else {
      this.request = { 'zone': this.access['zone'], 'region': this.access['region'] }
    }

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Frame-Options': 'DENY'
      })
    };

    this.http.post(this.service_name, this.request, httpOptions)
      .catch(error => {
        alert("Could not connect to the server. Retry after some time.")
        return EMPTY
      })
      .subscribe(data => {
        this.response = data
        this.serviceCalled()
      });

    this.http.post(this.service_name1, {}, httpOptions)
      .catch(error => {
        alert("Could not connect to the server. Retry after some time.")
        return EMPTY
      })
      .subscribe(data => {
        this.response1 = data
        this.serviceCalled1()
      });

      
  }
  
 
  serviceCalled() {
    if (this.response['status'] && this.response['status'] == "Success") {
      this.got_history = true
    }
    else {
      this.got_history = false
    }
  }

  serviceCalled1() {
    if (this.response1['status'] && this.response1['status'] == "Success") {
      this.got_report = true

    }
    else {
      this.got_report = false
    }
  }

  gotoDrilldown(arr, type) {

    if(type == 'atm') {
      localStorage.setItem('CMSAppUserDrillType',"ATM ID")
    }
    else if(type == 'branch') {
      localStorage.setItem('CMSAppUserDrillType',"Branch Name")
    }
    else if(type == 'route') {
      localStorage.setItem('CMSAppUserDrillType',"Route Number")
    }
    else if(type == 'vault') {
      localStorage.setItem('CMSAppUserDrillType',"Branch Name")
    }

    localStorage.setItem('CMSAppUserDrillArr',arr)

    this.router.navigate(["/drilldown"])
  }

  isMobileLogin() {
    if (this.isMobileMenu()) {
      return true
    }
    else {
      return false
    }
  }

  isMobileMenu() {
    if ($(window).width() > 991) {
      return false;
    }
    return true;
  };

}