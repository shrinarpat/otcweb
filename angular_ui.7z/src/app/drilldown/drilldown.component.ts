import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

declare const $: any;

import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/add/operator/catch';
import { EMPTY } from 'rxjs';

@Component({
  selector: 'app-drilldown',
  templateUrl: './drilldown.component.html',
  styleUrls: ['./drilldown.component.scss']
})
export class DrilldownComponent implements OnInit {

  server_json: any
  server_name: string
  service_name: string
  service_name_checklist: string
  service_name_image: string

  request: any
  response: any

  drilldown_list: any
  type: any
  audits: any

  request2: any
  response2: any
  chk_data: any
  chk_resp: any
  chk_cash: any
  chk_img: any

  request_img: any
  response_img: any

  got_drilldown: boolean = false
  got_checklist: boolean = false
  checklist_mode: boolean = false

  login_token: any
  access: any

  p: number = 1
  failure_message: string

  identifier_title: string
  identifier_value: string


  constructor(private router: Router, private http: HttpClient) { }

  ngOnInit() {

    this.server_json = require('./../../../config.json');
    this.server_name = this.server_json['server'];
    this.service_name = this.server_name.concat('/supervisor-drill')
    this.service_name_checklist = this.server_name.concat('/checklist')
    this.service_name_image = this.server_name.concat('/image-download')

    this.login_token = localStorage.getItem('CMSAppUserLogin');

    if (this.login_token) {
      this.access = JSON.parse(this.login_token);
      this.access['history'] = true
    }
    else {
      this.router.navigateByUrl('/', { skipLocationChange: false }).then(() =>
        this.router.navigate(["/login"]));
    }

    this.showAudits()

  }

  showAudits() {

    this.got_drilldown = false
    this.failure_message = "Loading..."
    var drill_arr = localStorage.getItem('CMSAppUserDrillArr')
    if (drill_arr) {

      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'X-Frame-Options': 'DENY'
        })
      };

      this.request = { 'arr_name': drill_arr }
      this.http.post(this.service_name, this.request, httpOptions)
        .catch(error => {
          alert("Could not connect to the server. Retry after some time.")
          return EMPTY
        })
        .subscribe(data => {
          this.response = data
          this.serviceCalled()
        });

    }
    else {
      this.got_drilldown = false
    }
  }

  serviceCalled() {
    var drill_identifier = localStorage.getItem('CMSAppUserDrillType')

    if (this.response['status'] && this.response['status'] == "Success") {
      this.got_drilldown = true
      this.identifier_title = drill_identifier
      this.audits = this.response['data']
    }

    else if (this.response['status'] && this.response['status'] == "Failure") {
      this.got_drilldown = false
      this.failure_message = this.response['error']
    }
    else {
      this.got_drilldown = false
      this.failure_message = "Loading"
    }
  }


  showChecklist(cid) {
    this.checklist_mode = true
    this.request2 = { 'checklist_id': cid }

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Frame-Options': 'DENY'
      })
    };

    this.http.post(this.service_name_checklist, this.request2, httpOptions)
      .catch(error => {
        alert("Could not connect to the server. Retry after some time.")
        return EMPTY
      })
      .subscribe(data => {
        this.response2 = data
        this.serviceCalled2()
      });

  }
  serviceCalled2() {

    if (this.response2['status'] && this.response2['status'] == "Success") {
      this.got_checklist = true
    }
    else {
      this.got_checklist = false
    }
    this.chk_data = this.response2['data']
    this.chk_resp = this.response2['responses']
    this.chk_img = this.response2['images']
    if (this.chk_data['checklist_type'] == "ATM") {
      this.chk_cash = this.response2['cash_count']
    }

  }

  downloadImage(img) {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Frame-Options': 'DENY'
      })
    };

    this.request_img = { 'image_name': img }

    this.http.post(this.service_name_image, this.request_img, httpOptions)
      .catch(error => {
        alert("Could not connect to the server. Retry after some time.")
        return EMPTY
      })
      .subscribe(data => {
        if (data['status'] && data['status'] == "Success") {
          this.response_img = data['image']
        }
        else {
          alert("Could not retrieve image from the server.")
        }
        window.open(this.response_img, '_blank');
      });

  }

  historyMode() {
    this.router.navigateByUrl('/', { skipLocationChange: false }).then(() =>
      this.router.navigate(["/history"]));
  }

  backToRecent() {
    this.checklist_mode = false
    this.chk_data = null
    this.scrollTop()
  }

  isMobileMenu() {
    if ($(window).width() > 991) {
      return false;
    }
    return true;
  };

  scrollTop() {
    var pageTop = document.querySelector('#pagetop');
    pageTop.scrollIntoView();
  }

}
